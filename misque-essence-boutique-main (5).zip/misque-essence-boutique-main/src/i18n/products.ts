import type { Dict } from "./index";

export const products: Dict = {};
