/* =====================================================================
 *  MISQÉ PARFUM — SITE TRANSLATIONS (RU / UZ / EN)
 * =====================================================================
 *  Every visible text of the site lives in the files below.
 *  To change a wording, edit the matching entry — nothing else.
 * ===================================================================== */

import type { Lang } from "@/lib/i18n";
import { common } from "./common";
import { home } from "./home";
import { shop } from "./shop";
import { cart } from "./cart";
import { pages } from "./pages";
import { products } from "./products";
import { system } from "./system";

export type Entry = Record<Lang, string>;
export type Dict = Record<string, Entry>;

export const DICT: Dict = {
  ...common,
  ...home,
  ...shop,
  ...cart,
  ...pages,
  ...products,
  ...system,
};
