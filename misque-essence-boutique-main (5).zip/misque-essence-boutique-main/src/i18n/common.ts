import type { Dict } from "./index";

export const common: Dict = {
  "nav.home": { ru: "Главная", uz: "Bosh sahifa", en: "Home" },
  "nav.shop": { ru: "Магазин", uz: "Do‘kon", en: "Shop" },
  "nav.men": { ru: "Мужские", uz: "Erkaklar", en: "Men" },
  "nav.women": { ru: "Женские", uz: "Ayollar", en: "Women" },
  "nav.unisex": { ru: "Унисекс", uz: "Uniseks", en: "Unisex" },
  "nav.best": { ru: "Бестселлеры", uz: "Bestsellerlar", en: "Best Sellers" },
  "nav.about": { ru: "О нас", uz: "Biz haqimizda", en: "About" },
  "nav.contact": { ru: "Контакты", uz: "Aloqa", en: "Contact" },

  "category.men": { ru: "Мужские", uz: "Erkaklar", en: "Men" },
  "category.women": { ru: "Женские", uz: "Ayollar", en: "Women" },
  "category.unisex": { ru: "Унисекс", uz: "Uniseks", en: "Unisex" },
  "category.best": { ru: "Бестселлеры", uz: "Bestsellerlar", en: "Best Sellers" },

  "header.openMenu": { ru: "Открыть меню", uz: "Menyuni ochish", en: "Open menu" },
  "header.closeMenu": { ru: "Закрыть меню", uz: "Menyuni yopish", en: "Close menu" },
  "header.search": { ru: "Поиск", uz: "Qidiruv", en: "Search" },
  "header.account": { ru: "Аккаунт", uz: "Hisob", en: "Account" },
  "header.shoppingBag": { ru: "Корзина", uz: "Savat", en: "Shopping bag" },
  "header.menu": { ru: "Меню", uz: "Menyu", en: "Menu" },
  "header.language": { ru: "Язык", uz: "Til", en: "Language" },
  "header.searchTitle": { ru: "Поиск по коллекции", uz: "Kolleksiyadan qidirish", en: "Search the collection" },
  "header.searchPlaceholder": {
    ru: "Поиск ароматов, нот, категорий…",
    uz: "Atirlar, notalar, kategoriyalarni qidiring…",
    en: "Search perfumes, notes, categories…",
  },
  "header.noResults": {
    ru: "Ароматы по запросу «{q}» не найдены.",
    uz: "«{q}» so‘rovi bo‘yicha atirlar topilmadi.",
    en: "No fragrances match “{q}”.",
  },

  "footer.tagline": {
    ru: "Современный аромат, созданный для тех, кто предпочитает быть запомненным, а не замеченным.",
    uz: "Zamonaviy atir — payqalishdan ko‘ra eslab qolinishni afzal ko‘radiganlar uchun yaratilgan.",
    en: "Modern fragrance, composed for those who prefer to be remembered rather than noticed.",
  },
  "footer.instagram": { ru: "Instagram", uz: "Instagram", en: "Instagram" },
  "footer.telegram": { ru: "Telegram", uz: "Telegram", en: "Telegram" },
  "footer.shop": { ru: "Магазин", uz: "Do‘kon", en: "Shop" },
  "footer.allFragrances": { ru: "Все ароматы", uz: "Barcha atirlar", en: "All Fragrances" },
  "footer.men": { ru: "Мужские", uz: "Erkaklar", en: "Men" },
  "footer.women": { ru: "Женские", uz: "Ayollar", en: "Women" },
  "footer.unisex": { ru: "Унисекс", uz: "Uniseks", en: "Unisex" },
  "footer.bestSellers": { ru: "Бестселлеры", uz: "Bestsellerlar", en: "Best Sellers" },
  "footer.maison": { ru: "О компании", uz: "Kompaniya", en: "Maison" },
  "footer.about": { ru: "О нас", uz: "Biz haqimizda", en: "About" },
  "footer.contact": { ru: "Контакты", uz: "Aloqa", en: "Contact" },
  "footer.delivery": { ru: "Доставка", uz: "Yetkazib berish", en: "Delivery" },
  "footer.legal": { ru: "Юридическая информация", uz: "Yuridik ma'lumot", en: "Legal" },
  "footer.privacy": { ru: "Политика конфиденциальности", uz: "Maxfiylik siyosati", en: "Privacy Policy" },
  "footer.terms": { ru: "Условия использования", uz: "Foydalanish shartlari", en: "Terms" },
  "footer.estd": { ru: "ОСНОВАНО", uz: "TASHKIL ETILGAN", en: "ESTD" },

  "card.addToCart": { ru: "В корзину", uz: "Savatga qo‘shish", en: "Add to Cart" },
  "card.soldOut": { ru: "Продано", uz: "Sotilgan", en: "Sold out" },
  "card.quickView": { ru: "Быстрый просмотр", uz: "Tezkor ko‘rish", en: "Quick View" },
  "card.removeFavorite": { ru: "Удалить из избранного", uz: "Sevimlilardan olib tashlash", en: "Remove from favourites" },
  "card.addFavorite": { ru: "Добавить в избранное", uz: "Sevimlilarga qo‘shish", en: "Add to favourites" },
  "card.reviews": { ru: "отзывов", uz: "sharh", en: "reviews" },
  "card.viewFullDetails": { ru: "Смотреть подробнее", uz: "To‘liq ma'lumot", en: "View full details" },
  "card.addedToBag": {
    ru: "{name} · {size}мл добавлен в корзину",
    uz: "{name} · {size}ml savatga qo‘shildi",
    en: "{name} · {size}ml added to your bag",
  },

  "size.size": { ru: "Размер", uz: "Hajm", en: "Size" },

  "telegram.orderViaTelegram": { ru: "Заказать в Telegram", uz: "Telegram orqali buyurtma", en: "Order via Telegram" },

  "common.rated": { ru: "Оценка {rating} из 5", uz: "{rating} / 5 baholandi", en: "Rated {rating} out of 5" },
};
