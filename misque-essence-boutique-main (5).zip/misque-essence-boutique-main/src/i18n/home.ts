import type { Dict } from "./index";

export const home: Dict = {
  "home.hero.eyebrow": {
    ru: "Дом парфюмерии · С {year} года",
    uz: "Parfyumeriya uyi · {year} yildan",
    en: "Maison de Parfum · Estd {year}",
  },
  "home.hero.title.line1": {
    ru: "Ваша подпись.",
    uz: "Sizning imzoingiz.",
    en: "Your Signature.",
  },
  "home.hero.title.line2": {
    ru: "Ваш аромат.",
    uz: "Sizning hidingiz.",
    en: "Your Scent.",
  },
  "home.hero.subtitle": {
    ru: "Откройте изысканные ароматы, созданные, чтобы стать частью вашей индивидуальности.",
    uz: "Shaxsiyatingizning bir qismiga aylanish uchun yaratilgan nafis hidlarni kashf eting.",
    en: "Discover refined fragrances created to become part of your identity.",
  },
  "home.hero.cta.shop": {
    ru: "Смотреть коллекцию",
    uz: "Kolleksiyani ko‘rish",
    en: "Shop Collection",
  },
  "home.hero.cta.discover": {
    ru: "Узнать о MISQÉ",
    uz: "MISQÉ haqida bilib oling",
    en: "Discover MISQÉ",
  },
  "home.marquee.extrait": {
    ru: "Extrait de Parfum",
    uz: "Extrait de Parfum",
    en: "Extrait de Parfum",
  },
  "home.marquee.freeDeliveryPrefix": {
    ru: "Бесплатная доставка от",
    uz: "Bepul yetkazib berish",
    en: "Free delivery over",
  },
  "home.marquee.crueltyFree": {
    ru: "Не тестируется на животных",
    uz: "Hayvonlarda sinovdan o‘tkazilmagan",
    en: "Cruelty free",
  },
  "home.marquee.telegram": {
    ru: "Заказ через Telegram",
    uz: "Telegram orqali buyurtma",
    en: "Order via Telegram",
  },
  "home.bestSellers.eyebrow": {
    ru: "Иконы",
    uz: "Ikonalar",
    en: "The Icons",
  },
  "home.bestSellers.title": {
    ru: "Хиты продаж",
    uz: "Eng ko‘p sotilganlar",
    en: "Best Sellers",
  },
  "home.bestSellers.copy": {
    ru: "Три композиции, к которым наши клиенты возвращаются сезон за сезоном.",
    uz: "Mijozlarimiz mavsumdan-mavsumga qaytadigan uchta kompozitsiya.",
    en: "Three compositions our clients return to, season after season.",
  },
  "home.bestSellers.viewAll": {
    ru: "Смотреть все хиты продаж",
    uz: "Barcha bestsellerlarni ko‘rish",
    en: "View all best sellers",
  },
  "home.story.eyebrow": {
    ru: "Дом",
    uz: "Uy",
    en: "The Maison",
  },
  "home.story.established": {
    ru: "Основан",
    uz: "Tashkil etilgan",
    en: "Established",
  },
  "home.story.title": {
    ru: "Искусство аромата",
    uz: "Hid san’ati",
    en: "The Art of Fragrance",
  },
  "home.story.p1": {
    ru: "MISQÉ PARFUM — современный дом парфюмерии, основанный в 2026 году для людей, для которых аромат — часть того, как они одеваются, говорят и остаются в памяти.",
    uz: "MISQÉ PARFUM — 2026 yilda hidni kiyinish, gapirish va xotirada qolish uslubining bir qismi deb biladigan odamlar uchun tashkil etilgan zamonaviy parfyumeriya uyi.",
    en: "MISQÉ PARFUM is a modern fragrance house founded in 2026 for people who treat scent as part of how they dress, speak and are remembered.",
  },
  "home.story.p2": {
    ru: "Каждая композиция создаётся небольшими партиями с высокой концентрацией масел — амбра, уд, ирис, кожа — чтобы шлейф оставался элегантным с утра до позднего вечера.",
    uz: "Har bir kompozitsiya ozgina sonli partiyalarda, moylarning yuqori konsentratsiyasi bilan yaratiladi — amber, ud, iris, teri — shuning uchun izi ertalabdan kechgacha nafis bo‘lib qoladi.",
    en: "Each composition is built in small batches with a high concentration of oils — amber, oud, iris, leather — so the trail stays elegant from morning to late evening.",
  },
  "home.story.cta": {
    ru: "Наша история",
    uz: "Bizning tariximiz",
    en: "Our story",
  },
  "home.newArrivals.eyebrow": {
    ru: "Новинки",
    uz: "Yangi kelganlar",
    en: "Just Landed",
  },
  "home.newArrivals.title": {
    ru: "Новые поступления",
    uz: "Yangi mahsulotlar",
    en: "New Arrivals",
  },
  "home.newArrivals.copy": {
    ru: "Последние дополнения к гардеробу MISQÉ.",
    uz: "MISQÉ garderobiga so‘nggi qo‘shimchalar.",
    en: "The latest additions to the MISQÉ wardrobe.",
  },
  "home.telegramCta.title": {
    ru: "Предпочитаете заказать по сообщению?",
    uz: "Xabar orqali buyurtma berishni afzal ko‘rasizmi?",
    en: "Prefer to order by message?",
  },
  "home.telegramCta.copy": {
    ru: "Отправьте нам ваш выбор в Telegram — мы подтвердим наличие, упакуем ваш заказ и организуем доставку лично.",
    uz: "Tanlovingizni Telegram orqali yuboring — biz mavjudligini tasdiqlaymiz, buyurtmangizni o‘raymiz va yetkazib berishni shaxsan tashkil qilamiz.",
    en: "Send us your selection on Telegram — we confirm availability, wrap your order and arrange delivery personally.",
  },
  "home.reviews.eyebrow": {
    ru: "Клиенты",
    uz: "Mijozlar",
    en: "Clientele",
  },
  "home.reviews.title": {
    ru: "Что говорят о нас",
    uz: "Ular nima deydi",
    en: "What They Say",
  },
  "home.reviews.copy": {
    ru: "Избранные отзывы сообщества MISQÉ.",
    uz: "MISQÉ jamoasining tanlangan fikrlari.",
    en: "Selected notes from the MISQÉ community.",
  },
  "home.reviews.1.text": {
    ru: "Упаковка, аромат, всё это ощущается как европейский бутик. Nuit Dorée незабываем.",
    uz: "Qadoqlash, hid, hammasi Yevropa butigi kabi his qilinadi. Nuit Dorée unutilmas.",
    en: "The packaging, the scent, the whole experience feels like a European boutique. Nuit Dorée is unforgettable.",
  },
  "home.reviews.1.date": {
    ru: "2 августа 2026",
    uz: "2-avgust 2026",
    en: "2 August 2026",
  },
  "home.reviews.2.text": {
    ru: "Onyx Noir держится весь рабочий день и вечером всё ещё пахнет изысканно. Стоит каждой копейки.",
    uz: "Onyx Noir butun ish kuni davomida saqlanadi va kechqurun ham nafis hidlaydi. Har bir tiyiniga arziydi.",
    en: "Onyx Noir lasts a full working day and still smells refined at night. Worth every cent.",
  },
  "home.reviews.2.date": {
    ru: "19 июля 2026",
    uz: "19-iyul 2026",
    en: "19 July 2026",
  },
  "home.reviews.3.text": {
    ru: "Заказала через Telegram, и заказ прибыл через два дня, красиво упакованный. Безупречный сервис.",
    uz: "Telegram orqali buyurtma berdim va u ikki kunda, chiroyli o‘ralgan holda yetib keldi. Benuqson xizmat.",
    en: "Ordered through Telegram and it arrived in two days, beautifully wrapped. Flawless service.",
  },
  "home.reviews.3.date": {
    ru: "5 июля 2026",
    uz: "5-iyul 2026",
    en: "5 July 2026",
  },
  "home.social.eyebrow": {
    ru: "@misqeparfum",
    uz: "@misqeparfum",
    en: "@misqeparfum",
  },
  "home.social.title": {
    ru: "Подписывайтесь на дом",
    uz: "Uyni kuzatib boring",
    en: "Follow the Maison",
  },
  "home.social.copy": {
    ru: "Кампании, новые релизы и закулисье создания ароматов.",
    uz: "Kampaniya suratlari, yangi chiqarilishlar va hid yaratish sirlari.",
    en: "Campaign imagery, new releases and behind the blend.",
  },
  "home.social.instagram": {
    ru: "Instagram",
    uz: "Instagram",
    en: "Instagram",
  },
  "home.alt.hero": {
    ru: "Флакон фирменного аромата MISQÉ PARFUM в золотом свете",
    uz: "Oltin yorug‘likda MISQÉ PARFUM imzo hidining shishasi",
    en: "MISQÉ PARFUM signature fragrance bottle in golden light",
  },
  "home.alt.woodAmberRoses": {
    ru: "Дерево уда, амбровая смола и сушёные розы",
    uz: "Ud yog‘ochi, amber smolasi va quritilgan atirgullar",
    en: "Oud wood, amber resin and dried roses",
  },
  "home.alt.boutiqueInterior": {
    ru: "Интерьер бутика MISQÉ PARFUM",
    uz: "MISQÉ PARFUM butigi interyeri",
    en: "MISQÉ PARFUM boutique interior",
  },
  "home.alt.lifestyle": {
    ru: "Лайфстайл-изображения MISQÉ PARFUM",
    uz: "MISQÉ PARFUM lifestyle tasvirlari",
    en: "MISQÉ PARFUM lifestyle imagery",
  },
};
