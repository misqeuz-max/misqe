import type { Dict } from "./index";

export const system: Dict = {
  "system.notFound.title": {
    ru: "Страница не найдена",
    uz: "Sahifa topilmadi",
    en: "Page not found",
  },
  "system.notFound.text": {
    ru: "Страница, которую вы ищете, не существует или была перемещена.",
    uz: "Siz izlagan sahifa mavjud emas yoki boshqa joyga ko‘chirilgan.",
    en: "The page you're looking for doesn't exist or has been moved.",
  },
  "system.notFound.cta": {
    ru: "На главную",
    uz: "Bosh sahifaga",
    en: "Return home",
  },
  "system.error.title": {
    ru: "Страница не загрузилась",
    uz: "Sahifa yuklanmadi",
    en: "This page didn't load",
  },
  "system.error.text": {
    ru: "Что-то пошло не так на нашей стороне. Обновите страницу или вернитесь на главную.",
    uz: "Bizning tomonda nimadir noto‘g‘ri ketdi. Sahifani yangilang yoki bosh sahifaga qayting.",
    en: "Something went wrong on our end. You can try refreshing or head back home.",
  },
  "system.error.retry": {
    ru: "Попробовать снова",
    uz: "Qayta urinish",
    en: "Try again",
  },
  "system.error.home": {
    ru: "На главную",
    uz: "Bosh sahifaga",
    en: "Go home",
  },
};
