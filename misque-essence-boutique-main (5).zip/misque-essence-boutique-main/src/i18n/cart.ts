import type { Dict } from "./index";

export const cart: Dict = {
  "cart.title": { ru: "Корзина", uz: "Xarid savati", en: "Shopping Bag" },
  "cart.empty": {
    ru: "Ваша корзина пуста.",
    uz: "Savatingiz hozircha bo‘sh.",
    en: "Your bag is currently empty.",
  },
  "cart.shopCollection": {
    ru: "Смотреть коллекцию",
    uz: "Kolleksiyani ko‘rish",
    en: "Shop Collection",
  },
  "cart.removeItem": { ru: "Удалить товар", uz: "Mahsulotni o‘chirish", en: "Remove item" },
  "cart.decreaseQty": {
    ru: "Уменьшить количество",
    uz: "Sonini kamaytirish",
    en: "Decrease quantity",
  },
  "cart.increaseQty": {
    ru: "Увеличить количество",
    uz: "Sonini oshirish",
    en: "Increase quantity",
  },
  "cart.orderSummary": {
    ru: "Сумма заказа",
    uz: "Buyurtma xulosasi",
    en: "Order Summary",
  },
  "cart.subtotal": { ru: "Подытог", uz: "Oraliq summa", en: "Subtotal" },
  "cart.delivery": { ru: "Доставка", uz: "Yetkazib berish", en: "Delivery" },
  "cart.free": { ru: "Бесплатно", uz: "Bepul", en: "Free" },
  "cart.total": { ru: "Итого", uz: "Jami", en: "Total" },
  "cart.freeDeliveryNote": {
    ru: "Бесплатная доставка при заказе от {amount}.",
    uz: "{amount} dan yuqori buyurtmalarda yetkazib berish bepul.",
    en: "Free delivery on orders over {amount}.",
  },
  "cart.checkout": { ru: "Оформить заказ", uz: "Buyurtma rasmiylashtirish", en: "Checkout" },
  "cart.continueShopping": {
    ru: "Продолжить покупки",
    uz: "Xaridni davom ettirish",
    en: "Continue shopping",
  },

  "checkout.title": { ru: "Оформление заказа", uz: "Buyurtmani rasmiylashtirish", en: "Checkout" },
  "checkout.subtitle": {
    ru: "Заполните данные — мы лично подтверждаем каждый заказ.",
    uz: "Ma'lumotlaringizni kiriting — biz har bir buyurtmani shaxsan tasdiqlaymiz.",
    en: "Complete your details — we confirm every order personally.",
  },
  "checkout.bagEmptyTitle": {
    ru: "Ваша корзина пуста",
    uz: "Savatingiz bo‘sh",
    en: "Your bag is empty",
  },
  "checkout.bagEmptyText": {
    ru: "Добавьте аромат перед оформлением заказа.",
    uz: "Buyurtma berishdan oldin atir qo‘shing.",
    en: "Add a fragrance before checking out.",
  },
  "checkout.fullName": { ru: "Полное имя", uz: "To‘liq ism", en: "Full Name" },
  "checkout.fullNamePlaceholder": {
    ru: "Ваше полное имя",
    uz: "To‘liq ismingiz",
    en: "Your full name",
  },
  "checkout.phone": { ru: "Номер телефона", uz: "Telefon raqami", en: "Phone Number" },
  "checkout.city": { ru: "Город", uz: "Shahar", en: "City" },
  "checkout.cityPlaceholder": { ru: "Город", uz: "Shahar", en: "City" },
  "checkout.address": { ru: "Адрес", uz: "Manzil", en: "Address" },
  "checkout.addressPlaceholder": {
    ru: "Улица, дом, квартира",
    uz: "Ko‘cha, uy, xonadon",
    en: "Street, building, apartment",
  },
  "checkout.deliveryMethod": {
    ru: "Способ доставки",
    uz: "Yetkazib berish usuli",
    en: "Delivery Method",
  },
  "checkout.delivery.standard.label": {
    ru: "Стандартная доставка",
    uz: "Standart yetkazib berish",
    en: "Standard delivery",
  },
  "checkout.delivery.standard.note": {
    ru: "2–5 рабочих дней",
    uz: "2–5 ish kuni",
    en: "2–5 business days",
  },
  "checkout.delivery.express.label": {
    ru: "Экспресс-доставка",
    uz: "Tezkor yetkazib berish",
    en: "Express delivery",
  },
  "checkout.delivery.express.note": {
    ru: "24–48 часов",
    uz: "24–48 soat",
    en: "24–48 hours",
  },
  "checkout.delivery.pickup.label": {
    ru: "Самовывоз из бутика",
    uz: "Butikdan olib ketish",
    en: "Boutique pickup",
  },
  "checkout.delivery.pickup.note": {
    ru: "Заберите в магазине",
    uz: "Do‘kondan oling",
    en: "Collect in store",
  },
  "checkout.orderNotes": { ru: "Комментарий к заказу", uz: "Buyurtma izohi", en: "Order Notes" },
  "checkout.orderNotesPlaceholder": {
    ru: "Подарочная упаковка, время доставки и прочее…",
    uz: "Sovg‘a qadoqlash, yetkazib berish vaqti va h.k…",
    en: "Gift wrapping, delivery time, anything else…",
  },
  "checkout.orderSummary": { ru: "Сумма заказа", uz: "Buyurtma xulosasi", en: "Order Summary" },
  "checkout.subtotal": { ru: "Подытог", uz: "Oraliq summa", en: "Subtotal" },
  "checkout.delivery": { ru: "Доставка", uz: "Yetkazib berish", en: "Delivery" },
  "checkout.free": { ru: "Бесплатно", uz: "Bepul", en: "Free" },
  "checkout.total": { ru: "Итого", uz: "Jami", en: "Total" },
  "checkout.placeOrder": { ru: "Оформить заказ", uz: "Buyurtma berish", en: "Place Order" },
  "checkout.paymentNote": {
    ru: "Оплата согласовывается после подтверждения. Вопросы?",
    uz: "To‘lov tasdiqlangandan so‘ng kelishiladi. Savollaringiz bormi?",
    en: "Payment is arranged on confirmation. Questions?",
  },
  "checkout.qty": { ru: "Кол-во", uz: "Soni", en: "Qty" },

  "confirmed.thanks": {
    ru: "Спасибо, что выбрали {brand}.",
    uz: "{brand}ni tanlaganingiz uchun rahmat.",
    en: "Thank you for choosing {brand}.",
  },
  "confirmed.text": {
    ru: "Ваш заказ получен. Наша команда свяжется с вами по указанному номеру, чтобы подтвердить детали доставки.",
    uz: "Buyurtmangiz qabul qilindi. Jamoamiz yetkazib berish tafsilotlarini tasdiqlash uchun siz bilan bog‘lanadi.",
    en: "Your order has been received. Our team will contact you shortly on the number you provided to confirm delivery details.",
  },
  "confirmed.continueShopping": {
    ru: "Продолжить покупки",
    uz: "Xaridni davom ettirish",
    en: "Continue shopping",
  },
};
