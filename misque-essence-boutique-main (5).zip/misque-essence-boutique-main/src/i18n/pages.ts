import type { Dict } from "./index";

export const pages: Dict = {};
