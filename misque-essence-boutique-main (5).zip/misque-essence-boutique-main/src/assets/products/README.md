# MISQÉ PARFUM — Product images

Put every perfume bottle photo in this folder.

## Replace an image
Upload your photo with the **same file name** (e.g. `perfume-1.jpg`) —
the website updates automatically, no code changes needed.

## Add a new image
1. Upload it here, e.g. `my-bottle.jpg`
2. Open `src/data/products.ts` and set `image: "my-bottle.jpg"` on the product.

## Rules
- Supported formats: `.jpg`, `.jpeg`, `.png`, `.webp`
- Images are shown fully centred on the black background — never stretched or cropped.
- Best results: square or 4:5 photo, bottle centred, dark/black background.

Current files: perfume-1 … perfume-8
