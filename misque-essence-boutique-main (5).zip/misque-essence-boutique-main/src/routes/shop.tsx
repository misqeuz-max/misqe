import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { ProductCard } from "@/components/ProductCard";
import { PRODUCTS } from "@/data/products";
import { money } from "@/config/site";
import { cn } from "@/lib/utils";
import { useT } from "@/lib/i18n";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Slider } from "@/components/ui/slider";

type ShopSearch = {
  category?: "all" | "men" | "women" | "unisex" | "best" | "new" | undefined;
  sort?: "featured" | "newest" | "price-asc" | "price-desc" | "rating" | undefined;
  max?: number | undefined;
};

const CATEGORIES: { key: ShopSearch["category"]; labelKey: string }[] = [
  { key: "all", labelKey: "shop.category.all" },
  { key: "men", labelKey: "shop.category.men" },
  { key: "women", labelKey: "shop.category.women" },
  { key: "unisex", labelKey: "shop.category.unisex" },
  { key: "best", labelKey: "shop.category.best" },
  { key: "new", labelKey: "shop.category.new" },
];

const MAX_PRICE = 300000;

export const Route = createFileRoute("/shop")({
  validateSearch: (search: Record<string, unknown>): ShopSearch => ({
    category: (CATEGORIES.some((c) => c.key === search["category"])
      ? search["category"]
      : "all") as ShopSearch["category"],
    sort: ([
      "featured",
      "newest",
      "price-asc",
      "price-desc",
      "rating",
    ].includes(String(search["sort"]))
      ? search["sort"]
      : "featured") as ShopSearch["sort"],
    max: Number(search["max"]) > 0 ? Number(search["max"]) : MAX_PRICE,
  }),
  head: () => ({
    meta: [
      { title: "Shop Fragrances — MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "Browse the full MISQÉ PARFUM catalogue: amber, oud, floral and leather fragrances for men, women and unisex. Filter by category, price and rating.",
      },
      { property: "og:title", content: "Shop Fragrances — MISQÉ PARFUM" },
      {
        property: "og:description",
        content:
          "The complete MISQÉ collection — filter by category, price and rating.",
      },
    ],
  }),
  component: Shop,
});

function Shop() {
  const t = useT();
  const { category = "all", sort = "featured", max = MAX_PRICE } = Route.useSearch();
  const navigate = useNavigate({ from: "/shop" });

  const setSearch = (patch: Partial<ShopSearch>) =>
    navigate({ search: (prev) => ({ ...prev, ...patch }) });

  let list = PRODUCTS.filter((p) => {
    if (p.price > max) return false;
    if (category === "all") return true;
    if (category === "best") return p.tags.includes("BEST SELLER");
    if (category === "new") return p.tags.includes("NEW");
    return p.category === category;
  });

  list = [...list].sort((a, b) => {
    switch (sort) {
      case "newest":
        return b.addedAt.localeCompare(a.addedAt);
      case "price-asc":
        return a.price - b.price;
      case "price-desc":
        return b.price - a.price;
      case "rating":
        return b.rating - a.rating;
      default:
        return a.featured - b.featured;
    }
  });

  return (
    <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
      <header className="text-center">
        <p className="text-[0.6rem] tracking-luxe text-gold uppercase">
          {t("shop.eyebrow")}
        </p>
        <h1 className="mt-4 font-serif text-5xl md:text-6xl">{t("shop.title")}</h1>
        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
          {t("shop.subtitle")}
        </p>
      </header>

      <div className="mt-14 hairline" />

      <div className="mt-8 flex flex-col gap-6 lg:flex-row lg:items-center lg:justify-between">
        <div className="flex flex-wrap gap-2">
          {CATEGORIES.map((c) => (
            <button
              key={c.key}
              type="button"
              onClick={() => setSearch({ category: c.key })}
              className={cn(
                "border px-5 py-2.5 text-[0.6rem] tracking-luxe uppercase transition-all duration-300",
                category === c.key
                  ? "border-gold bg-gold/10 text-gold"
                  : "border-border/60 text-muted-foreground hover:border-gold/60 hover:text-ivory",
              )}
            >
              {t(c.labelKey)}
            </button>
          ))}
        </div>

        <div className="flex flex-col gap-6 sm:flex-row sm:items-center">
          <div className="min-w-56">
            <div className="mb-2 flex items-center justify-between text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
              <span>{t("shop.filter.maxPrice")}</span>
              <span className="text-gold">{money(max)}</span>
            </div>
            <Slider
              value={[max]}
              min={50000}
              max={MAX_PRICE}
              step={10000}
              onValueChange={(v) => setSearch({ max: v[0] ?? MAX_PRICE })}
            />
          </div>

          <Select
            value={sort}
            onValueChange={(v) => setSearch({ sort: v as ShopSearch["sort"] })}
          >
            <SelectTrigger className="h-11 w-56 rounded-none border-border/60 bg-transparent text-[0.65rem] tracking-widest uppercase">
              <SelectValue />
            </SelectTrigger>
            <SelectContent className="rounded-none border-border/60 bg-card">
              <SelectItem value="featured">{t("shop.sort.featured")}</SelectItem>
              <SelectItem value="newest">{t("shop.sort.newest")}</SelectItem>
              <SelectItem value="price-asc">{t("shop.sort.priceAsc")}</SelectItem>
              <SelectItem value="price-desc">{t("shop.sort.priceDesc")}</SelectItem>
              <SelectItem value="rating">{t("shop.sort.rating")}</SelectItem>
            </SelectContent>
          </Select>
        </div>
      </div>

      <p className="mt-8 text-xs tracking-widest text-muted-foreground uppercase">
        {list.length} {list.length === 1 ? t("shop.count.fragrance") : t("shop.count.fragrances")}
      </p>

      <div className="mt-8 grid gap-10 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4">
        {list.map((p) => (
          <ProductCard key={p.slug} product={p} />
        ))}
      </div>

      {list.length === 0 && (
        <p className="py-24 text-center text-muted-foreground">
          {t("shop.empty")}
        </p>
      )}
    </div>
  );
}
