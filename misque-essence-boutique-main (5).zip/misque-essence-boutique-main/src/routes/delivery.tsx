import { createFileRoute } from "@tanstack/react-router";
import { TelegramOrderButton } from "@/components/TelegramOrderButton";
import { money, SITE } from "@/config/site";

export const Route = createFileRoute("/delivery")({
  head: () => ({
    meta: [
      { title: "Delivery & Returns — MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "MISQÉ PARFUM delivery options, timings, fees and returns policy. Free delivery on orders over $150.",
      },
      { property: "og:title", content: "Delivery & Returns — MISQÉ PARFUM" },
      {
        property: "og:description",
        content: "Delivery options, timings and returns for MISQÉ PARFUM orders.",
      },
    ],
  }),
  component: Delivery,
});

function Delivery() {
  return (
    <article className="mx-auto max-w-3xl px-6 py-20">
      <h1 className="font-serif text-5xl">Delivery & Returns</h1>
      <div className="mt-10 space-y-8 leading-relaxed text-muted-foreground">
        <section>
          <h2 className="font-serif text-2xl text-ivory">Options</h2>
          <ul className="mt-4 space-y-2">
            <li>Standard delivery — {money(SITE.deliveryFee)} · 2–5 business days</li>
            <li>Express delivery — {money(SITE.deliveryFee * 3)} · 24–48 hours</li>
            <li>Boutique pickup — free</li>
            <li>
              Free standard delivery on all orders over{" "}
              {money(SITE.freeDeliveryOver)}
            </li>
          </ul>
        </section>
        <section>
          <h2 className="font-serif text-2xl text-ivory">Dispatch</h2>
          <p className="mt-4">
            Orders placed before 16:00 are dispatched the same working day. You
            receive a confirmation message with tracking as soon as your parcel
            leaves our atelier.
          </p>
        </section>
        <section>
          <h2 className="font-serif text-2xl text-ivory">Returns</h2>
          <p className="mt-4">
            Unopened fragrances may be returned within 14 days of delivery in
            their original sealed packaging. Opened bottles cannot be returned
            for hygiene reasons. Damaged items are replaced immediately.
          </p>
        </section>
      </div>
      <div className="mt-12">
        <TelegramOrderButton variant="outlineGold" size="lg" />
      </div>
    </article>
  );
}
