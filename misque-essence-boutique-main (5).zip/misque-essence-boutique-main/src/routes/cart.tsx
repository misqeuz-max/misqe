import { createFileRoute, Link } from "@tanstack/react-router";
import { Minus, Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TelegramOrderButton } from "@/components/TelegramOrderButton";
import { useCart } from "@/lib/cart";
import { money, SITE } from "@/config/site";
import { useT } from "@/lib/i18n";

export const Route = createFileRoute("/cart")({
  head: () => ({
    meta: [
      { title: "Shopping Bag — MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "Review your MISQÉ PARFUM selection, adjust sizes and quantities, then check out or order via Telegram.",
      },
      { property: "og:title", content: "Shopping Bag — MISQÉ PARFUM" },
      {
        property: "og:description",
        content: "Review your fragrance selection and complete your order.",
      },
    ],
  }),
  component: CartPage,
});

function CartPage() {
  const t = useT();
  const { items, subtotal, delivery, total, setQty, remove } = useCart();

  return (
    <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
      <h1 className="font-serif text-5xl md:text-6xl">{t("cart.title")}</h1>

      {items.length === 0 ? (
        <div className="py-24 text-center">
          <p className="text-muted-foreground">{t("cart.empty")}</p>
          <div className="mt-8">
            <Button asChild variant="gold" size="xl">
              <Link to="/shop">{t("cart.shopCollection")}</Link>
            </Button>
          </div>
        </div>
      ) : (
        <div className="mt-12 grid gap-14 lg:grid-cols-[1.6fr_1fr]">
          <ul className="border-t border-border/60">
            {items.map((i) => (
              <li
                key={`${i.slug}-${i.size}`}
                className="flex gap-5 border-b border-border/60 py-8"
              >
                <Link
                  to="/product/$slug"
                  params={{ slug: i.slug }}
                  className="shrink-0"
                >
                  <img
                    src={i.product.images[0]}
                    alt={i.product.name}
                    loading="lazy"
                    className="h-32 w-24 object-cover sm:h-40 sm:w-32"
                  />
                </Link>
                <div className="flex flex-1 flex-col">
                  <div className="flex items-start justify-between gap-4">
                    <div>
                      <h2 className="font-serif text-2xl">
                        <Link
                          to="/product/$slug"
                          params={{ slug: i.slug }}
                          className="hover:text-gold"
                        >
                          {i.product.name}
                        </Link>
                      </h2>
                      <p className="mt-1 text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
                        {t(`category.${i.product.category}`)} · {i.size}ml
                      </p>
                    </div>
                    <button
                      type="button"
                      aria-label={t("cart.removeItem")}
                      onClick={() => remove(i.slug, i.size)}
                      className="p-1 text-muted-foreground transition-colors hover:text-destructive"
                    >
                      <X className="h-4 w-4" />
                    </button>
                  </div>

                  <div className="mt-auto flex flex-wrap items-center justify-between gap-4 pt-6">
                    <div className="inline-flex items-center border border-border/60">
                      <button
                        type="button"
                        aria-label={t("cart.decreaseQty")}
                        onClick={() => setQty(i.slug, i.size, i.qty - 1)}
                        className="px-3 py-2 text-ivory/70 hover:text-gold"
                      >
                        <Minus className="h-3.5 w-3.5" />
                      </button>
                      <span className="w-10 text-center text-sm">{i.qty}</span>
                      <button
                        type="button"
                        aria-label={t("cart.increaseQty")}
                        onClick={() => setQty(i.slug, i.size, i.qty + 1)}
                        className="px-3 py-2 text-ivory/70 hover:text-gold"
                      >
                        <Plus className="h-3.5 w-3.5" />
                      </button>
                    </div>
                    <p className="text-lg text-gold">{money(i.lineTotal)}</p>
                  </div>
                </div>
              </li>
            ))}
          </ul>

          <aside className="h-fit border border-border/60 bg-card p-8">
            <h2 className="text-[0.6rem] tracking-luxe text-gold uppercase">
              {t("cart.orderSummary")}
            </h2>
            <dl className="mt-8 space-y-4 text-sm">
              <Row label={t("cart.subtotal")} value={money(subtotal)} />
              <Row
                label={t("cart.delivery")}
                value={delivery === 0 ? t("cart.free") : money(delivery)}
              />
              <div className="hairline my-4" />
              <div className="flex items-center justify-between">
                <dt className="text-[0.65rem] tracking-luxe uppercase">
                  {t("cart.total")}
                </dt>
                <dd className="font-serif text-3xl text-gold">{money(total)}</dd>
              </div>
            </dl>
            <p className="mt-4 text-xs text-muted-foreground">
              {t("cart.freeDeliveryNote").replace(
                "{amount}",
                money(SITE.freeDeliveryOver),
              )}
            </p>
            <div className="mt-8 flex flex-col gap-3">
              <Button asChild variant="gold" size="xl">
                <Link to="/checkout">{t("cart.checkout")}</Link>
              </Button>
              <TelegramOrderButton />
              <Button asChild variant="ghost" size="lg">
                <Link to="/shop">{t("cart.continueShopping")}</Link>
              </Button>
            </div>
          </aside>
        </div>
      )}
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex items-center justify-between">
      <dt className="text-muted-foreground">{label}</dt>
      <dd>{value}</dd>
    </div>
  );
}
