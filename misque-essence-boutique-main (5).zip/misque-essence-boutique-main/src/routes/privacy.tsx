import { createFileRoute } from "@tanstack/react-router";
import { SITE } from "@/config/site";

export const Route = createFileRoute("/privacy")({
  head: () => ({
    meta: [
      { title: "Privacy Policy — MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "How MISQÉ PARFUM collects, uses and protects your personal information when you shop or contact us.",
      },
      { property: "og:title", content: "Privacy Policy — MISQÉ PARFUM" },
      {
        property: "og:description",
        content: "How MISQÉ PARFUM handles and protects your personal data.",
      },
    ],
  }),
  component: Privacy,
});

function Privacy() {
  return (
    <article className="mx-auto max-w-3xl px-6 py-20">
      <h1 className="font-serif text-5xl">Privacy Policy</h1>
      <div className="mt-10 space-y-8 leading-relaxed text-muted-foreground">
        <p>
          {SITE.brand} collects only the information required to process and
          deliver your order: name, phone number, delivery address and any notes
          you choose to share.
        </p>
        <section>
          <h2 className="font-serif text-2xl text-ivory">How we use it</h2>
          <p className="mt-4">
            Your details are used to confirm your order, arrange delivery and
            answer client care enquiries. We never sell or rent personal data to
            third parties.
          </p>
        </section>
        <section>
          <h2 className="font-serif text-2xl text-ivory">Messaging</h2>
          <p className="mt-4">
            If you order through Telegram, your message is handled inside
            Telegram under their own privacy terms. We retain only the order
            details needed for fulfilment.
          </p>
        </section>
        <section>
          <h2 className="font-serif text-2xl text-ivory">Your rights</h2>
          <p className="mt-4">
            You may request a copy or deletion of your data at any time by
            writing to {SITE.email}.
          </p>
        </section>
      </div>
    </article>
  );
}
