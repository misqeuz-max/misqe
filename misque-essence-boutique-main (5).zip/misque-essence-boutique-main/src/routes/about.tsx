import { createFileRoute, Link } from "@tanstack/react-router";
import s3 from "@/assets/s3.jpg";
import s4 from "@/assets/s4.jpg";
import s2 from "@/assets/s2.jpg";
import { Button } from "@/components/ui/button";
import { SITE } from "@/config/site";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "The Art of Fragrance — About MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "MISQÉ PARFUM is a modern fragrance house established in 2026, composing elegant, memorable and sophisticated scents in small batches.",
      },
      { property: "og:title", content: "The Art of Fragrance — About MISQÉ PARFUM" },
      {
        property: "og:description",
        content:
          "A modern fragrance house established in 2026. Discover the MISQÉ philosophy.",
      },
    ],
  }),
  component: About,
});

function About() {
  return (
    <>
      <section className="relative overflow-hidden border-b border-border/60">
        <img
          src={s2}
          alt="Applying MISQÉ PARFUM fragrance"
          className="absolute inset-0 h-full w-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-onyx/75" />
        <div className="relative mx-auto max-w-3xl px-6 py-28 text-center">
          <p className="text-[0.6rem] tracking-luxe text-gold uppercase">
            Estd {SITE.established}
          </p>
          <h1 className="mt-6 font-serif text-5xl md:text-7xl">
            The Art of Fragrance
          </h1>
          <p className="mt-6 leading-relaxed text-ivory/75">
            MISQÉ PARFUM is a modern fragrance brand focused on elegant,
            memorable and sophisticated scents.
          </p>
        </div>
      </section>

      <section className="mx-auto grid max-w-7xl items-center gap-14 px-6 py-24 lg:grid-cols-2 lg:px-10">
        <div>
          <h2 className="font-serif text-4xl">Composed, not manufactured</h2>
          <p className="mt-6 leading-relaxed text-muted-foreground">
            Founded in 2026, MISQÉ began with a simple conviction: a fragrance
            should feel personal before it feels expensive. Every composition is
            developed slowly — trialled on skin, adjusted, and only released
            when it earns its place in the collection.
          </p>
          <p className="mt-4 leading-relaxed text-muted-foreground">
            We work with high concentrations of essential oils and absolutes:
            Cambodian oud, Taif rose, iris pallida, birch leather. The result is
            a wardrobe of scents that stay close to the skin, evolve through the
            day and remain unmistakably yours.
          </p>
          <div className="mt-10 grid grid-cols-3 gap-6 border-t border-border/60 pt-8">
            <Stat value="18" label="Compositions" />
            <Stat value="12h+" label="Longevity" />
            <Stat value="100%" label="Cruelty free" />
          </div>
        </div>
        <img
          src={s3}
          alt="Raw perfume ingredients: oud, amber and rose"
          loading="lazy"
          className="aspect-4/5 w-full object-cover"
        />
      </section>

      <section className="border-y border-border/60 bg-onyx">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-6 py-24 lg:grid-cols-2 lg:px-10">
          <img
            src={s4}
            alt="MISQÉ PARFUM boutique"
            loading="lazy"
            className="aspect-square w-full object-cover"
          />
          <div>
            <p className="text-[0.6rem] tracking-luxe text-gold uppercase">
              The Promise
            </p>
            <h2 className="mt-5 font-serif text-4xl">
              Quiet luxury, personally delivered
            </h2>
            <p className="mt-6 leading-relaxed text-muted-foreground">
              Each order is wrapped by hand and confirmed by a real person —
              online, or directly through Telegram if you prefer to message us.
              Free delivery on orders over {SITE.currency}
              {SITE.freeDeliveryOver}.
            </p>
            <div className="mt-10 flex flex-wrap gap-3">
              <Button asChild variant="gold" size="xl">
                <Link to="/shop" search={{}}>
                  Shop Collection
                </Link>
              </Button>
              <Button asChild variant="outlineGold" size="xl">
                <Link to="/contact">Contact us</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}

function Stat({ value, label }: { value: string; label: string }) {
  return (
    <div>
      <p className="font-serif text-3xl text-gold">{value}</p>
      <p className="mt-1 text-[0.55rem] tracking-luxe text-muted-foreground uppercase">
        {label}
      </p>
    </div>
  );
}
