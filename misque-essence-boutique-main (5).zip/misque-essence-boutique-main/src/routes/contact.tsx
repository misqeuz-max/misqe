import { useState } from "react";
import { createFileRoute } from "@tanstack/react-router";
import { Instagram, Mail, Phone, Send } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { TelegramOrderButton } from "@/components/TelegramOrderButton";
import { SITE, telegramUrl } from "@/config/site";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact & Client Care — MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "Reach MISQÉ PARFUM client care by message, email or Telegram for orders, fragrance advice and delivery enquiries.",
      },
      { property: "og:title", content: "Contact & Client Care — MISQÉ PARFUM" },
      {
        property: "og:description",
        content: "Fragrance advice, orders and delivery support from MISQÉ PARFUM.",
      },
    ],
  }),
  component: Contact,
});

function Contact() {
  const [sent, setSent] = useState(false);

  return (
    <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
      <header className="text-center">
        <p className="text-[0.6rem] tracking-luxe text-gold uppercase">
          Client Care
        </p>
        <h1 className="mt-4 font-serif text-5xl md:text-6xl">Contact MISQÉ</h1>
        <p className="mx-auto mt-4 max-w-xl text-muted-foreground">
          Fragrance advice, order status, gifting or wholesale — we answer every
          message personally.
        </p>
      </header>

      <div className="mt-16 grid gap-14 lg:grid-cols-[1.3fr_1fr]">
        <form
          className="space-y-8"
          onSubmit={(e) => {
            e.preventDefault();
            setSent(true);
            toast.success("Message sent — we'll reply within 24 hours.");
          }}
        >
          <div className="grid gap-8 sm:grid-cols-2">
            <div>
              <Label className="mb-3 block text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
                Full Name
              </Label>
              <Input
                required
                className="h-12 rounded-none border-border/60 bg-transparent"
              />
            </div>
            <div>
              <Label className="mb-3 block text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
                Phone or Email
              </Label>
              <Input
                required
                className="h-12 rounded-none border-border/60 bg-transparent"
              />
            </div>
          </div>
          <div>
            <Label className="mb-3 block text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
              Message
            </Label>
            <Textarea
              required
              rows={6}
              className="rounded-none border-border/60 bg-transparent"
            />
          </div>
          <Button type="submit" variant="gold" size="xl">
            {sent ? "Message sent" : "Send message"}
          </Button>
        </form>

        <aside className="space-y-px border border-border/60">
          <Item icon={<Send className="h-4 w-4" />} title="Telegram">
            <a
              href={telegramUrl()}
              target="_blank"
              rel="noreferrer"
              className="text-gold hover:underline"
            >
              {SITE.telegramUsername}
            </a>
          </Item>
          <Item icon={<Mail className="h-4 w-4" />} title="Email">
            {SITE.email}
          </Item>
          <Item icon={<Phone className="h-4 w-4" />} title="Phone">
            {SITE.phone}
          </Item>
          <Item icon={<Instagram className="h-4 w-4" />} title="Instagram">
            <a
              href={SITE.instagramUrl}
              target="_blank"
              rel="noreferrer"
              className="text-gold hover:underline"
            >
              @misqeparfum
            </a>
          </Item>
          <div className="bg-card p-8">
            <p className="text-sm text-muted-foreground">
              Prefer to order by message? Send your selection and we handle the
              rest.
            </p>
            <div className="mt-6">
              <TelegramOrderButton variant="outlineGold" size="lg" />
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
}

function Item({
  icon,
  title,
  children,
}: {
  icon: React.ReactNode;
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div className="flex items-start gap-4 bg-card p-8">
      <span className="mt-1 text-gold">{icon}</span>
      <div>
        <p className="text-[0.55rem] tracking-luxe text-muted-foreground uppercase">
          {title}
        </p>
        <p className="mt-2 text-sm">{children}</p>
      </div>
    </div>
  );
}
