import { createFileRoute } from "@tanstack/react-router";
import { SITE } from "@/config/site";

export const Route = createFileRoute("/terms")({
  head: () => ({
    meta: [
      { title: "Terms of Sale — MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "Terms and conditions covering orders, pricing, delivery and product use for MISQÉ PARFUM fragrances.",
      },
      { property: "og:title", content: "Terms of Sale — MISQÉ PARFUM" },
      {
        property: "og:description",
        content: "Order, pricing and delivery terms for MISQÉ PARFUM.",
      },
    ],
  }),
  component: Terms,
});

function Terms() {
  return (
    <article className="mx-auto max-w-3xl px-6 py-20">
      <h1 className="font-serif text-5xl">Terms of Sale</h1>
      <div className="mt-10 space-y-8 leading-relaxed text-muted-foreground">
        <section>
          <h2 className="font-serif text-2xl text-ivory">Orders</h2>
          <p className="mt-4">
            An order becomes binding once {SITE.brand} confirms availability by
            phone, email or Telegram. We reserve the right to decline an order
            where stock or delivery cannot be guaranteed.
          </p>
        </section>
        <section>
          <h2 className="font-serif text-2xl text-ivory">Pricing</h2>
          <p className="mt-4">
            All prices are shown in {SITE.currency} and include applicable
            taxes. Delivery fees are displayed before you place your order.
          </p>
        </section>
        <section>
          <h2 className="font-serif text-2xl text-ivory">Product use</h2>
          <p className="mt-4">
            Fragrance is for external use only. Discontinue use if irritation
            occurs. Store away from direct sunlight and heat to preserve the
            composition.
          </p>
        </section>
        <section>
          <h2 className="font-serif text-2xl text-ivory">Contact</h2>
          <p className="mt-4">
            Questions about these terms: {SITE.email} · {SITE.phone}
          </p>
        </section>
      </div>
    </article>
  );
}
