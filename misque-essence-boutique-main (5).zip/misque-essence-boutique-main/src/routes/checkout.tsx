import { useState } from "react";
import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { TelegramOrderButton } from "@/components/TelegramOrderButton";
import { useCart } from "@/lib/cart";
import { money, SITE } from "@/config/site";

export const Route = createFileRoute("/checkout")({
  head: () => ({
    meta: [
      { title: "Checkout — MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "Complete your MISQÉ PARFUM order: delivery details, order summary and confirmation. Telegram ordering available.",
      },
      { property: "og:title", content: "Checkout — MISQÉ PARFUM" },
      {
        property: "og:description",
        content: "Complete your MISQÉ PARFUM fragrance order.",
      },
    ],
  }),
  component: Checkout,
});

const DELIVERY_METHODS = [
  { id: "standard", label: "Standard delivery", note: "2–5 business days" },
  { id: "express", label: "Express delivery", note: "24–48 hours" },
  { id: "pickup", label: "Boutique pickup", note: "Collect in store" },
];

function Checkout() {
  const { items, subtotal, delivery, total, clear } = useCart();
  const navigate = useNavigate();
  const [form, setForm] = useState({
    name: "",
    phone: "",
    city: "",
    address: "",
    delivery: "standard",
    notes: "",
  });

  const set = (key: keyof typeof form, value: string) =>
    setForm((f) => ({ ...f, [key]: value }));

  const method = DELIVERY_METHODS.find((m) => m.id === form.delivery);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (items.length === 0) return;
    clear();
    navigate({ to: "/order-confirmed" });
  };

  if (items.length === 0) {
    return (
      <div className="mx-auto max-w-2xl px-6 py-32 text-center">
        <h1 className="font-serif text-4xl">Your bag is empty</h1>
        <p className="mt-4 text-muted-foreground">
          Add a fragrance before checking out.
        </p>
        <div className="mt-10">
          <Button asChild variant="gold" size="xl">
            <Link to="/shop" search={{}}>
              Shop Collection
            </Link>
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
      <h1 className="font-serif text-5xl md:text-6xl">Checkout</h1>
      <p className="mt-3 text-muted-foreground">
        Complete your details — we confirm every order personally.
      </p>

      <form
        onSubmit={submit}
        className="mt-12 grid gap-14 lg:grid-cols-[1.5fr_1fr]"
      >
        <div className="space-y-8">
          <Field label="Full Name" required>
            <Input
              required
              value={form.name}
              onChange={(e) => set("name", e.target.value)}
              placeholder="Your full name"
              className="h-12 rounded-none border-border/60 bg-transparent"
            />
          </Field>

          <Field label="Phone Number" required>
            <Input
              required
              type="tel"
              value={form.phone}
              onChange={(e) => set("phone", e.target.value)}
              placeholder="+1 000 000 0000"
              className="h-12 rounded-none border-border/60 bg-transparent"
            />
          </Field>

          <div className="grid gap-8 sm:grid-cols-2">
            <Field label="City" required>
              <Input
                required
                value={form.city}
                onChange={(e) => set("city", e.target.value)}
                placeholder="City"
                className="h-12 rounded-none border-border/60 bg-transparent"
              />
            </Field>
            <Field label="Address" required>
              <Input
                required
                value={form.address}
                onChange={(e) => set("address", e.target.value)}
                placeholder="Street, building, apartment"
                className="h-12 rounded-none border-border/60 bg-transparent"
              />
            </Field>
          </div>

          <Field label="Delivery Method">
            <RadioGroup
              value={form.delivery}
              onValueChange={(v) => set("delivery", v)}
              className="grid gap-3"
            >
              {DELIVERY_METHODS.map((m) => (
                <label
                  key={m.id}
                  className="flex cursor-pointer items-center gap-4 border border-border/60 px-5 py-4 transition-colors hover:border-gold/60 has-[button[data-state=checked]]:border-gold"
                >
                  <RadioGroupItem value={m.id} className="border-gold text-gold" />
                  <span>
                    <span className="block text-sm text-ivory">{m.label}</span>
                    <span className="block text-xs text-muted-foreground">
                      {m.note}
                    </span>
                  </span>
                </label>
              ))}
            </RadioGroup>
          </Field>

          <Field label="Order Notes">
            <Textarea
              value={form.notes}
              onChange={(e) => set("notes", e.target.value)}
              placeholder="Gift wrapping, delivery time, anything else…"
              rows={4}
              className="rounded-none border-border/60 bg-transparent"
            />
          </Field>
        </div>

        <aside className="h-fit border border-border/60 bg-card p-8">
          <h2 className="text-[0.6rem] tracking-luxe text-gold uppercase">
            Order Summary
          </h2>
          <ul className="mt-8 space-y-5">
            {items.map((i) => (
              <li key={`${i.slug}-${i.size}`} className="flex gap-4">
                <img
                  src={i.product.images[0]}
                  alt={i.product.name}
                  loading="lazy"
                  className="h-20 w-16 object-cover"
                />
                <div className="flex-1 text-sm">
                  <p className="font-serif text-lg">{i.product.name}</p>
                  <p className="text-xs text-muted-foreground">
                    {i.size}ml · Qty {i.qty}
                  </p>
                </div>
                <p className="text-sm text-gold">{money(i.lineTotal)}</p>
              </li>
            ))}
          </ul>

          <div className="mt-8 space-y-4 border-t border-border/60 pt-6 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Subtotal</span>
              <span>{money(subtotal)}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Delivery</span>
              <span>{delivery === 0 ? "Free" : money(delivery)}</span>
            </div>
            <div className="hairline my-2" />
            <div className="flex items-center justify-between">
              <span className="text-[0.65rem] tracking-luxe uppercase">Total</span>
              <span className="font-serif text-3xl text-gold">{money(total)}</span>
            </div>
          </div>

          <div className="mt-8 flex flex-col gap-3">
            <Button type="submit" variant="gold" size="xl">
              Place Order
            </Button>
            <TelegramOrderButton
              details={{
                name: form.name,
                phone: form.phone,
                city: form.city,
                address: form.address,
                delivery: method?.label,
                notes: form.notes,
              }}
            />
          </div>
          <p className="mt-5 text-center text-xs text-muted-foreground">
            Payment is arranged on confirmation. Questions? {SITE.email}
          </p>
        </aside>
      </form>
    </div>
  );
}

function Field({
  label,
  required,
  children,
}: {
  label: string;
  required?: boolean;
  children: React.ReactNode;
}) {
  return (
    <div>
      <Label className="mb-3 block text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
        {label}
        {required && <span className="ml-1 text-gold">*</span>}
      </Label>
      {children}
    </div>
  );
}
