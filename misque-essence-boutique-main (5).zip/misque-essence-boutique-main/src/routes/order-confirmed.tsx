import { createFileRoute, Link } from "@tanstack/react-router";
import { Check } from "lucide-react";
import { Button } from "@/components/ui/button";
import { TelegramOrderButton } from "@/components/TelegramOrderButton";
import { SITE } from "@/config/site";
import { useT } from "@/lib/i18n";

export const Route = createFileRoute("/order-confirmed")({
  head: () => ({
    meta: [
      { title: "Order Confirmed — MISQÉ PARFUM" },
      {
        name: "description",
        content:
          "Your MISQÉ PARFUM order has been received. We will contact you shortly to confirm delivery.",
      },
      { name: "robots", content: "noindex" },
      { property: "og:title", content: "Order Confirmed — MISQÉ PARFUM" },
      {
        property: "og:description",
        content: "Thank you for choosing MISQÉ PARFUM.",
      },
    ],
  }),
  component: OrderConfirmed,
});

function OrderConfirmed() {
  const t = useT();

  return (
    <div className="mx-auto max-w-2xl px-6 py-32 text-center">
      <div className="mx-auto flex h-16 w-16 items-center justify-center rounded-full border border-gold/60">
        <Check className="h-6 w-6 text-gold" />
      </div>
      <h1 className="mt-10 font-serif text-4xl md:text-5xl">
        {t("confirmed.thanks").replace("{brand}", SITE.brand)}
      </h1>
      <p className="mt-6 leading-relaxed text-muted-foreground">
        {t("confirmed.text")}
      </p>
      <div className="mt-12 flex flex-col justify-center gap-3 sm:flex-row">
        <Button asChild variant="gold" size="xl">
          <Link to="/shop" search={{}}>
            {t("confirmed.continueShopping")}
          </Link>
        </Button>
        <TelegramOrderButton />
      </div>
    </div>
  );
}
