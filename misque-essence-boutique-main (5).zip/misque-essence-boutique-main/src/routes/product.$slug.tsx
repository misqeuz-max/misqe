import { useState } from "react";
import { createFileRoute, Link, notFound, useNavigate } from "@tanstack/react-router";
import { Check, Minus, Plus, Truck } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { StarRating } from "@/components/StarRating";
import { SizeSelector } from "@/components/SizeSelector";
import { ProductCard } from "@/components/ProductCard";
import { TelegramOrderButton } from "@/components/TelegramOrderButton";
import { useCart } from "@/lib/cart";
import { money, SITE } from "@/config/site";
import { PRODUCTS, getProduct, priceFor, type SizeML } from "@/data/products";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/product/$slug")({
  loader: ({ params }) => {
    const product = getProduct(params.slug);
    if (!product) throw notFound();
    return { product };
  },
  head: ({ loaderData }) => {
    if (!loaderData) {
      return {
        meta: [
          { title: "Fragrance unavailable — MISQÉ PARFUM" },
          { name: "robots", content: "noindex" },
        ],
      };
    }
    const p = loaderData.product;
    const title = `${p.name} — MISQÉ PARFUM`;
    return {
      meta: [
        { title },
        { name: "description", content: p.short },
        { property: "og:title", content: title },
        { property: "og:description", content: p.short },
      ],
    };
  },
  component: ProductPage,
});

function ProductPage() {
  const { product } = Route.useLoaderData();
  const { add } = useCart();
  const navigate = useNavigate();
  const [size, setSize] = useState<SizeML>(50);
  const [qty, setQty] = useState(1);
  const [active, setActive] = useState(0);

  const unit = priceFor(product, size);
  const related = PRODUCTS.filter(
    (p) => p.slug !== product.slug && p.category === product.category,
  )
    .concat(PRODUCTS.filter((p) => p.slug !== product.slug))
    .slice(0, 4);

  const addToCart = () => {
    add(product.slug, size, qty);
    toast.success(`${product.name} · ${size}ml × ${qty} added to your bag`);
  };

  return (
    <div className="mx-auto max-w-7xl px-6 py-12 lg:px-10">
      <nav className="text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
        <Link to="/" className="hover:text-gold">
          Home
        </Link>
        <span className="px-2">/</span>
        <Link to="/shop" className="hover:text-gold">
          Shop
        </Link>
        <span className="px-2">/</span>
        <span className="text-gold">{product.name}</span>
      </nav>

      <div className="mt-10 grid gap-14 lg:grid-cols-2">
        {/* GALLERY */}
        <div>
          <div className="overflow-hidden bg-onyx">
            <img
              src={product.images[active]}
              alt={`${product.name} — view ${active + 1}`}
              width={1024}
              height={1280}
              className="aspect-4/5 w-full object-contain p-6"
            />
          </div>
          <div className="mt-4 grid grid-cols-3 gap-4">
            {product.images.map((img, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setActive(i)}
                className={cn(
                  "overflow-hidden border transition-colors",
                  i === active ? "border-gold" : "border-border/50 hover:border-gold/60",
                )}
              >
                <img
                  src={img}
                  alt={`${product.name} thumbnail ${i + 1}`}
                  loading="lazy"
                  className="aspect-square w-full bg-onyx object-contain p-2"
                />
              </button>
            ))}
          </div>
        </div>

        {/* DETAILS */}
        <div>
          <div className="flex flex-wrap gap-2">
            {product.tags.map((t) => (
              <span
                key={t}
                className="border border-gold/50 px-2.5 py-1 text-[0.55rem] tracking-luxe text-gold uppercase"
              >
                {t}
              </span>
            ))}
          </div>
          <p className="mt-5 text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
            {product.category} · Extrait de Parfum
          </p>
          <h1 className="mt-3 font-serif text-5xl md:text-6xl">{product.name}</h1>

          <div className="mt-5 flex items-center gap-3">
            <StarRating rating={product.rating} size={16} />
            <span className="text-sm text-muted-foreground">
              {product.rating.toFixed(1)} · {product.reviewCount} reviews
            </span>
          </div>

          <p className="mt-6 leading-relaxed text-muted-foreground">
            {product.description}
          </p>

          <p className="mt-8 font-serif text-4xl text-gold">{money(unit)}</p>

          <div className="mt-8">
            <SizeSelector product={product} value={size} onChange={setSize} />
          </div>

          {/* QUANTITY */}
          <div className="mt-8">
            <p className="mb-3 text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
              Quantity
            </p>
            <div className="inline-flex items-center border border-border/60">
              <button
                type="button"
                aria-label="Decrease quantity"
                onClick={() => setQty((q) => Math.max(1, q - 1))}
                className="px-4 py-3 text-ivory/70 transition-colors hover:text-gold"
              >
                <Minus className="h-3.5 w-3.5" />
              </button>
              <span className="w-12 text-center text-sm">{qty}</span>
              <button
                type="button"
                aria-label="Increase quantity"
                onClick={() => setQty((q) => Math.min(10, q + 1))}
                className="px-4 py-3 text-ivory/70 transition-colors hover:text-gold"
              >
                <Plus className="h-3.5 w-3.5" />
              </button>
            </div>
          </div>

          <div className="mt-10 flex flex-col gap-3">
            <Button
              variant="gold"
              size="xl"
              disabled={!product.inStock}
              onClick={addToCart}
            >
              {product.inStock ? "Add to Cart" : "Currently sold out"}
            </Button>
            <Button
              variant="ivory"
              size="xl"
              disabled={!product.inStock}
              onClick={() => {
                add(product.slug, size, qty);
                navigate({ to: "/checkout" });
              }}
            >
              Buy Now
            </Button>
            <TelegramOrderButton productName={`${product.name} ${size}ml`} />
          </div>

          <ul className="mt-10 space-y-3 border-t border-border/60 pt-8 text-sm text-muted-foreground">
            <li className="flex items-center gap-3">
              <Check
                className={cn(
                  "h-4 w-4",
                  product.inStock ? "text-gold" : "text-destructive",
                )}
              />
              {product.inStock ? "In stock — ships within 24 hours" : "Out of stock — restocking soon"}
            </li>
            <li className="flex items-center gap-3">
              <Truck className="h-4 w-4 text-gold" />
              Delivery {money(SITE.deliveryFee)} · free over {money(SITE.freeDeliveryOver)} · 2–5 business days
            </li>
          </ul>
        </div>
      </div>

      {/* FRAGRANCE NOTES */}
      <section className="mt-24 border-y border-border/60 bg-onyx">
        <div className="grid gap-px md:grid-cols-3">
          {(
            [
              ["Top Notes", product.notes.top],
              ["Heart Notes", product.notes.heart],
              ["Base Notes", product.notes.base],
            ] as const
          ).map(([title, notes]) => (
            <div key={title} className="bg-card p-10 text-center">
              <h3 className="text-[0.6rem] tracking-luxe text-gold uppercase">
                {title}
              </h3>
              <ul className="mt-6 space-y-2">
                {notes.map((n) => (
                  <li key={n} className="font-serif text-2xl">
                    {n}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </section>

      {/* REVIEWS */}
      <section className="mt-24">
        <h2 className="font-serif text-4xl">Customer Reviews</h2>
        <div className="mt-10 grid gap-10 md:grid-cols-2">
          {product.reviews.map((r) => (
            <figure key={r.name} className="border border-border/60 p-8">
              <StarRating rating={r.rating} />
              <blockquote className="mt-5 leading-relaxed text-muted-foreground">
                “{r.text}”
              </blockquote>
              <figcaption className="mt-6 text-sm">
                <span className="text-ivory">{r.name}</span>
                <span className="ml-3 text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
                  {r.date}
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* RELATED */}
      <section className="mt-24">
        <h2 className="font-serif text-4xl">You May Also Like</h2>
        <div className="mt-10 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {related.map((p) => (
            <ProductCard key={p.slug} product={p} />
          ))}
        </div>
      </section>
    </div>
  );
}
