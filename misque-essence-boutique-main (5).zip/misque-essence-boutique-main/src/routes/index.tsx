import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight } from "lucide-react";
import heroImg from "@/assets/hero.jpg";
import s1 from "@/assets/s1.jpg";
import s2 from "@/assets/s2.jpg";
import s3 from "@/assets/s3.jpg";
import s4 from "@/assets/s4.jpg";
import { Button } from "@/components/ui/button";
import { ProductCard } from "@/components/ProductCard";
import { StarRating } from "@/components/StarRating";
import { TelegramOrderButton } from "@/components/TelegramOrderButton";
import { PRODUCTS, bestSellers } from "@/data/products";
import { SITE, money } from "@/config/site";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "MISQÉ PARFUM — Your Signature. Your Scent." },
      {
        name: "description",
        content:
          "Discover MISQÉ PARFUM: refined niche fragrances for men, women and unisex. Amber, oud, florals and leather — established 2026.",
      },
      { property: "og:title", content: "MISQÉ PARFUM — Your Signature. Your Scent." },
      {
        property: "og:description",
        content:
          "Refined fragrances created to become part of your identity. Shop the MISQÉ collection.",
      },
    ],
  }),
  component: Home,
});

const REVIEWS = [
  {
    name: "Yasmin A.",
    date: "2 August 2026",
    text: "The packaging, the scent, the whole experience feels like a European boutique. Nuit Dorée is unforgettable.",
  },
  {
    name: "Marcus L.",
    date: "19 July 2026",
    text: "Onyx Noir lasts a full working day and still smells refined at night. Worth every cent.",
  },
  {
    name: "Elif D.",
    date: "5 July 2026",
    text: "Ordered through Telegram and it arrived in two days, beautifully wrapped. Flawless service.",
  },
];

function Home() {
  const featured = bestSellers().slice(0, 3);
  const newArrivals = PRODUCTS.filter((p) => p.tags.includes("NEW")).slice(0, 4);

  return (
    <>
      {/* HERO */}
      <section className="relative -mt-20 flex min-h-[92vh] items-center overflow-hidden bg-onyx">
        <img
          src={heroImg}
          alt="MISQÉ PARFUM signature fragrance bottle in golden light"
          width={1920}
          height={1280}
          className="absolute inset-0 h-full w-full object-cover opacity-70"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-onyx via-onyx/80 to-onyx/20" />
        <div className="absolute inset-0 veil" />

        <div className="relative mx-auto w-full max-w-7xl px-6 pt-28 pb-20 lg:px-10">
          <p className="text-[0.6rem] tracking-luxe text-gold uppercase">
            Maison de Parfum · Estd {SITE.established}
          </p>
          <h1 className="mt-6 max-w-3xl font-serif text-5xl leading-[1.05] sm:text-6xl md:text-7xl lg:text-8xl">
            Your Signature.
            <br />
            <span className="text-gold-gradient italic">Your Scent.</span>
          </h1>
          <p className="mt-7 max-w-lg text-base leading-relaxed text-ivory/75 md:text-lg">
            Discover refined fragrances created to become part of your identity.
          </p>
          <div className="mt-10 flex flex-col gap-4 sm:flex-row">
            <Button asChild variant="gold" size="xl">
              <Link to="/shop">Shop Collection</Link>
            </Button>
            <Button asChild variant="outlineGold" size="xl">
              <Link to="/about">Discover MISQÉ</Link>
            </Button>
          </div>
        </div>
      </section>

      {/* MARQUEE STRIP */}
      <div className="border-y border-border/60 bg-onyx">
        <div className="mx-auto flex max-w-7xl flex-wrap items-center justify-center gap-x-12 gap-y-3 px-6 py-5 text-[0.55rem] tracking-luxe text-muted-foreground uppercase">
          <span>Extrait de Parfum</span>
          <span className="text-gold">·</span>
          <span>Free delivery over {money(SITE.freeDeliveryOver)}</span>
          <span className="text-gold">·</span>
          <span>Cruelty free</span>
          <span className="text-gold">·</span>
          <span>Order via Telegram</span>
        </div>
      </div>

      {/* BEST SELLERS */}
      <section className="mx-auto max-w-7xl px-6 py-24 lg:px-10">
        <SectionHeading
          eyebrow="The Icons"
          title="Best Sellers"
          copy="Three compositions our clients return to, season after season."
        />
        <div className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-3">
          {featured.map((p) => (
            <ProductCard key={p.slug} product={p} />
          ))}
        </div>
        <div className="mt-14 text-center">
          <Button asChild variant="outlineGold" size="lg">
            <Link to="/shop" search={{ category: "best" }}>
              View all best sellers <ArrowRight className="h-4 w-4" />
            </Link>
          </Button>
        </div>
      </section>

      {/* BRAND STORY */}
      <section className="border-y border-border/60 bg-onyx">
        <div className="mx-auto grid max-w-7xl items-center gap-14 px-6 py-24 lg:grid-cols-2 lg:px-10">
          <div className="relative">
            <img
              src={s3}
              alt="Oud wood, amber resin and dried roses"
              loading="lazy"
              width={900}
              height={900}
              className="aspect-square w-full object-cover"
            />
            <div className="absolute -right-4 -bottom-6 hidden border border-gold/40 bg-onyx/90 px-8 py-6 backdrop-blur-sm md:block">
              <p className="font-serif text-4xl text-gold">2026</p>
              <p className="mt-1 text-[0.55rem] tracking-luxe text-muted-foreground uppercase">
                Established
              </p>
            </div>
          </div>
          <div>
            <p className="text-[0.6rem] tracking-luxe text-gold uppercase">
              The Maison
            </p>
            <h2 className="mt-5 font-serif text-4xl md:text-5xl">
              The Art of Fragrance
            </h2>
            <p className="mt-6 leading-relaxed text-muted-foreground">
              MISQÉ PARFUM is a modern fragrance house founded in 2026 for people
              who treat scent as part of how they dress, speak and are
              remembered.
            </p>
            <p className="mt-4 leading-relaxed text-muted-foreground">
              Each composition is built in small batches with a high
              concentration of oils — amber, oud, iris, leather — so the trail
              stays elegant from morning to late evening.
            </p>
            <div className="mt-10">
              <Button asChild variant="outlineGold" size="lg">
                <Link to="/about">Our story</Link>
              </Button>
            </div>
          </div>
        </div>
      </section>

      {/* NEW ARRIVALS */}
      <section className="mx-auto max-w-7xl px-6 py-24 lg:px-10">
        <SectionHeading
          eyebrow="Just Landed"
          title="New Arrivals"
          copy="The latest additions to the MISQÉ wardrobe."
        />
        <div className="mt-14 grid gap-10 sm:grid-cols-2 lg:grid-cols-4">
          {newArrivals.map((p) => (
            <ProductCard key={p.slug} product={p} />
          ))}
        </div>
      </section>

      {/* TELEGRAM CTA */}
      <section className="relative overflow-hidden border-y border-border/60">
        <img
          src={s4}
          alt="MISQÉ PARFUM boutique interior"
          loading="lazy"
          className="absolute inset-0 h-full w-full object-cover opacity-25"
        />
        <div className="absolute inset-0 bg-onyx/80" />
        <div className="relative mx-auto max-w-3xl px-6 py-24 text-center">
          <h2 className="font-serif text-4xl md:text-5xl">
            Prefer to order by message?
          </h2>
          <p className="mt-5 text-muted-foreground">
            Send us your selection on Telegram — we confirm availability, wrap
            your order and arrange delivery personally.
          </p>
          <div className="mt-10 flex justify-center">
            <TelegramOrderButton variant="gold" />
          </div>
        </div>
      </section>

      {/* REVIEWS */}
      <section className="mx-auto max-w-7xl px-6 py-24 lg:px-10">
        <SectionHeading
          eyebrow="Clientele"
          title="What They Say"
          copy="Selected notes from the MISQÉ community."
        />
        <div className="mt-14 grid gap-px overflow-hidden border border-border/60 md:grid-cols-3">
          {REVIEWS.map((r) => (
            <figure key={r.name} className="bg-card p-10">
              <StarRating rating={5} size={15} />
              <blockquote className="mt-6 font-serif text-xl leading-relaxed italic">
                “{r.text}”
              </blockquote>
              <figcaption className="mt-8">
                <span className="block text-sm text-ivory">{r.name}</span>
                <span className="mt-1 block text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
                  {r.date}
                </span>
              </figcaption>
            </figure>
          ))}
        </div>
      </section>

      {/* SOCIAL */}
      <section className="border-t border-border/60 bg-onyx">
        <div className="mx-auto max-w-7xl px-6 py-24 lg:px-10">
          <SectionHeading
            eyebrow="@misqeparfum"
            title="Follow the Maison"
            copy="Campaign imagery, new releases and behind the blend."
          />
          <div className="mt-14 grid grid-cols-2 gap-4 md:grid-cols-4">
            {[s1, s2, s3, s4].map((img, i) => (
              <a
                key={i}
                href={SITE.instagramUrl}
                target="_blank"
                rel="noreferrer"
                className="group relative overflow-hidden"
              >
                <img
                  src={img}
                  alt="MISQÉ PARFUM lifestyle imagery"
                  loading="lazy"
                  width={900}
                  height={900}
                  className="aspect-square w-full object-cover transition-transform duration-[900ms] group-hover:scale-105"
                />
                <span className="absolute inset-0 bg-onyx/60 opacity-0 transition-opacity duration-500 group-hover:opacity-100" />
              </a>
            ))}
          </div>
          <div className="mt-12 flex flex-wrap justify-center gap-4">
            <Button asChild variant="outlineGold" size="lg">
              <a href={SITE.instagramUrl} target="_blank" rel="noreferrer">
                Instagram
              </a>
            </Button>
            <TelegramOrderButton variant="outlineGold" size="lg" />
          </div>
        </div>
      </section>
    </>
  );
}

export function SectionHeading({
  eyebrow,
  title,
  copy,
  align = "center",
}: {
  eyebrow: string;
  title: string;
  copy?: string;
  align?: "center" | "left";
}) {
  return (
    <div className={align === "center" ? "text-center" : ""}>
      <p className="text-[0.6rem] tracking-luxe text-gold uppercase">{eyebrow}</p>
      <h2 className="mt-4 font-serif text-4xl md:text-5xl">{title}</h2>
      {copy && (
        <p
          className={`mt-4 text-muted-foreground ${align === "center" ? "mx-auto max-w-xl" : "max-w-xl"}`}
        >
          {copy}
        </p>
      )}
    </div>
  );
}
