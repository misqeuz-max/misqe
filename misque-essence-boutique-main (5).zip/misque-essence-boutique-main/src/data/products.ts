/* =====================================================================
 *  MISQÉ PARFUM — PRODUCT DATA (EDIT THIS FILE ONLY)
 * =====================================================================
 *
 *  HOW TO EDIT YOUR PRODUCTS
 *  -------------------------
 *  Everything you need is in the PRODUCTS list below. For each perfume
 *  you can change:
 *
 *    name        -> Product name
 *    price       -> Price in som for the 50ml bottle (10ml / 30ml are
 *                   calculated automatically, see SIZE_MULTIPLIER)
 *    short       -> Short description shown on the product card
 *    description -> Long description shown on the product page
 *    category    -> "men" | "women" | "unisex"
 *    image       -> Image FILE NAME inside  src/assets/products/
 *    badges      -> "BEST SELLER" | "NEW" | "LIMITED" | "EXCLUSIVE"
 *    rating      -> 0 to 5 (e.g. 4.8)
 *    reviewCount -> Number of reviews
 *    inStock     -> true / false
 *
 *  HOW TO CHANGE A PRODUCT IMAGE
 *  -----------------------------
 *  1. Open the folder:  src/assets/products/
 *  2. Replace a file (for example perfume-1.jpg) with your own photo,
 *     keeping the SAME file name -> the site updates automatically.
 *  3. Or upload a new file (my-bottle.jpg) and write that file name in
 *     the "image" field below.
 *
 *  Supported formats: .jpg  .jpeg  .png  .webp
 *  (If you change the extension, e.g. perfume-1.png, you can still just
 *   write "perfume-1" and the correct file is found automatically.)
 *
 *  Images are never stretched — they are shown fully, centred, on the
 *  black luxury background.
 * ===================================================================== */

export type Category = "men" | "women" | "unisex";
export type Tag = "BEST SELLER" | "NEW" | "LIMITED" | "EXCLUSIVE";
export type SizeML = 10 | 30 | 50;

export interface Review {
  name: string;
  rating: number;
  date: string;
  text: string;
}

/* ---------------------------------------------------------------------
 *  Image loader — finds any file inside src/assets/products/
 *  You never need to touch this.
 * ------------------------------------------------------------------- */
const productImages = import.meta.glob<string>(
  "../assets/products/*.{jpg,jpeg,png,webp,JPG,JPEG,PNG,WEBP}",
  { eager: true, query: "?url", import: "default" },
);

const imageMap: Record<string, string> = {};
for (const [path, url] of Object.entries(productImages)) {
  const file = path.split("/").pop()!;
  imageMap[file.toLowerCase()] = url;
  imageMap[file.replace(/\.[^.]+$/, "").toLowerCase()] = url; // name without extension
}

/** Resolve an image file name from src/assets/products/ */
export const productImage = (fileName: string): string =>
  imageMap[fileName.toLowerCase()] ??
  imageMap[fileName.replace(/\.[^.]+$/, "").toLowerCase()] ??
  "";

/* ---------------------------------------------------------------------
 *  Size pricing — 50ml is the base price you enter below.
 *    10ml = 20% of base   (150 000 → 30 000)
 *    30ml = 60% of base   (150 000 → 90 000)
 *    50ml = 100% of base  (150 000 → 150 000)
 * ------------------------------------------------------------------- */
export const SIZE_MULTIPLIER: Record<SizeML, number> = {
  10: 0.2,
  30: 0.6,
  50: 1.0,
};

/* ---------------------------------------------------------------------
 *  Customer reviews (optional) — reuse these on any product.
 * ------------------------------------------------------------------- */
const reviewsA: Review[] = [
  {
    name: "Laylo H.",
    rating: 5,
    date: "12 July 2026",
    text: "Rich, warm and long lasting. I get compliments every single time I wear it.",
  },
  {
    name: "Daniyor R.",
    rating: 5,
    date: "28 June 2026",
    text: "Feels far more expensive than it is. The dry-down is beautiful.",
  },
  {
    name: "Amira K.",
    rating: 4,
    date: "3 June 2026",
    text: "Elegant and refined. I wish the opening lasted a little longer.",
  },
];

const reviewsB: Review[] = [
  {
    name: "Sofiya M.",
    rating: 5,
    date: "9 August 2026",
    text: "My signature scent now. Soft, clean and undeniably luxurious.",
  },
  {
    name: "Omar B.",
    rating: 5,
    date: "21 July 2026",
    text: "Projection is excellent without ever being loud. Beautiful packaging too.",
  },
];

/* =====================================================================
 *  YOUR PRODUCTS — edit / add / remove entries here
 * ===================================================================== */
export interface ProductInput {
  /** URL id, e.g. "bvlgary-tygar" -> /product/bvlgary-tygar */
  slug: string;
  name: string;
  price: number;
  short: string;
  description: string;
  category: Category;
  /** File name inside src/assets/products/ */
  image: string;
  /** Extra photos (optional) — also file names in src/assets/products/ */
  gallery?: string[];
  badges?: Tag[];
  rating: number;
  reviewCount: number;
  inStock?: boolean;
  notes?: { top: string[]; heart: string[]; base: string[] };
  reviews?: Review[];
  /** Date added — used for the "Newest" sorting */
  addedAt?: string;
}

const PRODUCT_LIST: ProductInput[] = [
  {
    slug: "herrera-aqua-carolina-herrera",
    name: "HERRERA AQUA — Carolina Herrera",
    price: 150000,
    short:
      "HERRERA AQUA от Carolina Herrera — мужской аромат, где морская свежесть раскрывается в тёплой глубине амбра. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "HERRERA AQUA — легендарное творение дома Carolina Herrera, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот морская свежесть, бергамот, мандарин, плавно перетекая в чувственное сердце из лаванда, морская соль, розмарин. Шлейф завершается глубокими, обволакивающими нотами амбра, кедр, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-1.jpg",
    gallery: ["perfume-2.jpg"],
    badges: ["NEW"],
    rating: 4.6,
    reviewCount: 35,
    inStock: false,
    notes: {
      top: ["Морская свежесть", "Бергамот", "Мандарин"],
      heart: ["Лаванда", "Морская соль", "Розмарин"],
      base: ["Амбра", "Кедр", "Мускус"],
    },
    reviews: reviewsA,
    addedAt: "2026-01-03",
  },
  {
    slug: "elysium-roja-parfums",
    name: "ELYSIUM — Roja Parfums",
    price: 150000,
    short:
      "ELYSIUM от Roja Parfums — мужской аромат, где цитрусовый бергамот раскрывается в тёплой глубине ветивер. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "ELYSIUM — легендарное творение дома Roja Parfums, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот цитрусовый бергамот, кардамон, розовый перец, плавно перетекая в чувственное сердце из лаванда, шалфей, герань. Шлейф завершается глубокими, обволакивающими нотами ветивер, кедр, амброксан, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-2.jpg",
    gallery: ["perfume-3.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.7,
    reviewCount: 42,
    inStock: true,
    notes: {
      top: ["Цитрусовый бергамот", "Кардамон", "Розовый перец"],
      heart: ["Лаванда", "Шалфей", "Герань"],
      base: ["Ветивер", "Кедр", "Амброксан"],
    },
    reviews: reviewsB,
    addedAt: "2026-02-04",
  },
  {
    slug: "terre-dhermes-hermes",
    name: "TERRE D'HERMES — Hermès",
    price: 150000,
    short:
      "TERRE D'HERMES от Hermès — мужской аромат, где грейпфрут раскрывается в тёплой глубине ветивер. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "TERRE D'HERMES — легендарное творение дома Hermès, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот грейпфрут, апельсин, минеральные ноты, плавно перетекая в чувственное сердце из перец, герань, пачули. Шлейф завершается глубокими, обволакивающими нотами ветивер, кедр, бензоин, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-3.jpg",
    gallery: ["perfume-4.jpg"],
    badges: [],
    rating: 4.8,
    reviewCount: 49,
    inStock: true,
    notes: {
      top: ["Грейпфрут", "Апельсин", "Минеральные ноты"],
      heart: ["Перец", "Герань", "Пачули"],
      base: ["Ветивер", "Кедр", "Бензоин"],
    },
    reviews: reviewsA,
    addedAt: "2026-03-05",
  },
  {
    slug: "invictus-paco-rabanne",
    name: "INVICTUS — Paco Rabanne",
    price: 150000,
    short:
      "INVICTUS от Paco Rabanne — мужской аромат, где морская вода раскрывается в тёплой глубине гваяковое дерево. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "INVICTUS — легендарное творение дома Paco Rabanne, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот морская вода, грейпфрут, мандарин, плавно перетекая в чувственное сердце из лавр, гвоздика. Шлейф завершается глубокими, обволакивающими нотами гваяковое дерево, амбра, пачули, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-4.jpg",
    gallery: ["perfume-5.jpg"],
    badges: ["NEW"],
    rating: 4.9,
    reviewCount: 56,
    inStock: true,
    notes: {
      top: ["Морская вода", "Грейпфрут", "Мандарин"],
      heart: ["Лавр", "Гвоздика"],
      base: ["Гваяковое дерево", "Амбра", "Пачули"],
    },
    reviews: reviewsB,
    addedAt: "2026-04-06",
  },
  {
    slug: "aqua-marine-bvlgari",
    name: "AQUA MARINE — Bvlgari",
    price: 150000,
    short:
      "AQUA MARINE от Bvlgari — мужской аромат, где морские ноты раскрывается в тёплой глубине амбра серая. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "AQUA MARINE — легендарное творение дома Bvlgari, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот морские ноты, лимон, розмарин, плавно перетекая в чувственное сердце из мандариновое дерево, жасмин. Шлейф завершается глубокими, обволакивающими нотами амбра серая, кедр, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-5.jpg",
    gallery: ["perfume-6.jpg"],
    badges: [],
    rating: 4.6,
    reviewCount: 63,
    inStock: true,
    notes: {
      top: ["Морские ноты", "Лимон", "Розмарин"],
      heart: ["Мандариновое дерево", "Жасмин"],
      base: ["Амбра серая", "Кедр", "Мускус"],
    },
    reviews: reviewsA,
    addedAt: "2026-05-07",
  },
  {
    slug: "in-blue-armand-basi",
    name: "IN BLUE — Armand Basi",
    price: 150000,
    short:
      "IN BLUE от Armand Basi — мужской аромат, где бергамот раскрывается в тёплой глубине ветивер. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "IN BLUE — легендарное творение дома Armand Basi, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот бергамот, мята, яблоко, плавно перетекая в чувственное сердце из кардамон, лаванда, кориандр. Шлейф завершается глубокими, обволакивающими нотами ветивер, пачули, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-6.jpg",
    gallery: ["perfume-7.jpg"],
    badges: [],
    rating: 4.7,
    reviewCount: 70,
    inStock: true,
    notes: {
      top: ["Бергамот", "Мята", "Яблоко"],
      heart: ["Кардамон", "Лаванда", "Кориандр"],
      base: ["Ветивер", "Пачули", "Амбра"],
    },
    reviews: reviewsB,
    addedAt: "2026-06-08",
  },
  {
    slug: "aventus-creed",
    name: "AVENTUS — Creed",
    price: 150000,
    short:
      "AVENTUS от Creed — мужской аромат, где ананас раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "AVENTUS — легендарное творение дома Creed, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот ананас, чёрная смородина, бергамот, яблоко, плавно перетекая в чувственное сердце из берёза, пачули, роза марокко. Шлейф завершается глубокими, обволакивающими нотами мускус, дубовый мох, амбра, ваниль, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-7.jpg",
    gallery: ["perfume-8.jpg"],
    badges: ["BEST SELLER"],
    rating: 4.8,
    reviewCount: 77,
    inStock: true,
    notes: {
      top: ["Ананас", "Чёрная смородина", "Бергамот", "Яблоко"],
      heart: ["Берёза", "Пачули", "Роза Марокко"],
      base: ["Мускус", "Дубовый мох", "Амбра", "Ваниль"],
    },
    reviews: reviewsA,
    addedAt: "2026-07-09",
  },
  {
    slug: "sauvage-dior",
    name: "SAUVAGE — Dior",
    price: 150000,
    short:
      "SAUVAGE от Dior — мужской аромат, где калабрийский бергамот раскрывается в тёплой глубине амброксан. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "SAUVAGE — легендарное творение дома Dior, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот калабрийский бергамот, перец, плавно перетекая в чувственное сердце из сычуаньский перец, лаванда, пink pepper, пачули. Шлейф завершается глубокими, обволакивающими нотами амброксан, кедр, лабданум, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-8.jpg",
    gallery: ["perfume-1.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.9,
    reviewCount: 84,
    inStock: true,
    notes: {
      top: ["Калабрийский бергамот", "Перец"],
      heart: ["Сычуаньский перец", "Лаванда", "Пink pepper", "Пачули"],
      base: ["Амброксан", "Кедр", "Лабданум"],
    },
    reviews: reviewsB,
    addedAt: "2026-08-10",
  },
  {
    slug: "one-million-paco-rabanne",
    name: "ONE MILLION — Paco Rabanne",
    price: 150000,
    short:
      "ONE MILLION от Paco Rabanne — мужской аромат, где кровавый апельсин раскрывается в тёплой глубине кожа. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "ONE MILLION — легендарное творение дома Paco Rabanne, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот кровавый апельсин, грейпфрут, мята, плавно перетекая в чувственное сердце из корица, роза, ландыш. Шлейф завершается глубокими, обволакивающими нотами кожа, дубовый мох, янтарь, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-1.jpg",
    gallery: ["perfume-2.jpg"],
    badges: [],
    rating: 4.6,
    reviewCount: 91,
    inStock: true,
    notes: {
      top: ["Кровавый апельсин", "Грейпфрут", "Мята"],
      heart: ["Корица", "Роза", "Ландыш"],
      base: ["Кожа", "Дубовый мох", "Янтарь"],
    },
    reviews: reviewsA,
    addedAt: "2026-09-11",
  },
  {
    slug: "stronger-with-you-emporio-armani",
    name: "STRONGER WITH YOU — Emporio Armani",
    price: 150000,
    short:
      "STRONGER WITH YOU от Emporio Armani — мужской аромат, где кардамон раскрывается в тёплой глубине ваниль. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "STRONGER WITH YOU — легендарное творение дома Emporio Armani, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот кардамон, розовый перец, плавно перетекая в чувственное сердце из каштан, кедровое дерево, шалфей. Шлейф завершается глубокими, обволакивающими нотами ваниль, сандал, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-2.jpg",
    gallery: ["perfume-3.jpg"],
    badges: ["BEST SELLER"],
    rating: 4.7,
    reviewCount: 98,
    inStock: true,
    notes: {
      top: ["Кардамон", "Розовый перец"],
      heart: ["Каштан", "Кедровое дерево", "Шалфей"],
      base: ["Ваниль", "Сандал", "Амбра"],
    },
    reviews: reviewsB,
    addedAt: "2026-10-12",
  },
  {
    slug: "acqua-di-gio-giorgio-armani",
    name: "ACQUA DI GIO — Giorgio Armani",
    price: 150000,
    short:
      "ACQUA DI GIO от Giorgio Armani — мужской аромат, где морская нота раскрывается в тёплой глубине белый мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "ACQUA DI GIO — легендарное творение дома Giorgio Armani, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот морская нота, лайм, бергамот, плавно перетекая в чувственное сердце из жасмин, розмарин, персик. Шлейф завершается глубокими, обволакивающими нотами белый мускус, кедр, пачули, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-3.jpg",
    gallery: ["perfume-4.jpg"],
    badges: [],
    rating: 4.8,
    reviewCount: 105,
    inStock: true,
    notes: {
      top: ["Морская нота", "Лайм", "Бергамот"],
      heart: ["Жасмин", "Розмарин", "Персик"],
      base: ["Белый мускус", "Кедр", "Пачули"],
    },
    reviews: reviewsA,
    addedAt: "2026-11-13",
  },
  {
    slug: "bleu-de-chanel-chanel",
    name: "BLEU DE CHANEL — Chanel",
    price: 150000,
    short:
      "BLEU DE CHANEL от Chanel — мужской аромат, где грейпфрут раскрывается в тёплой глубине ладан. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "BLEU DE CHANEL — легендарное творение дома Chanel, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот грейпфрут, лимон, мята, плавно перетекая в чувственное сердце из имбирь, никотиана, мускатный орех. Шлейф завершается глубокими, обволакивающими нотами ладан, ветивер, сандал, пачули, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-4.jpg",
    gallery: ["perfume-5.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.9,
    reviewCount: 112,
    inStock: true,
    notes: {
      top: ["Грейпфрут", "Лимон", "Мята"],
      heart: ["Имбирь", "Никотиана", "Мускатный орех"],
      base: ["Ладан", "Ветивер", "Сандал", "Пачули"],
    },
    reviews: reviewsB,
    addedAt: "2026-12-14",
  },
  {
    slug: "212-sexy-men-carolina-herrera",
    name: "212 SEXY MEN — Carolina Herrera",
    price: 150000,
    short:
      "212 SEXY MEN от Carolina Herrera — мужской аромат, где бергамот раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "212 SEXY MEN — легендарное творение дома Carolina Herrera, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот бергамот, кориандр, плавно перетекая в чувственное сердце из ирис, кожа, ветивер. Шлейф завершается глубокими, обволакивающими нотами кедр, мускус, табак, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-5.jpg",
    gallery: ["perfume-6.jpg"],
    badges: [],
    rating: 4.6,
    reviewCount: 119,
    inStock: true,
    notes: {
      top: ["Бергамот", "Кориандр"],
      heart: ["Ирис", "Кожа", "Ветивер"],
      base: ["Кедр", "Мускус", "Табак"],
    },
    reviews: reviewsA,
    addedAt: "2026-01-15",
  },
  {
    slug: "chrome-azzaro",
    name: "CHROME — Azzaro",
    price: 150000,
    short:
      "CHROME от Azzaro — мужской аромат, где цитрус раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "CHROME — легендарное творение дома Azzaro, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот цитрус, морские ноты, плавно перетекая в чувственное сердце из роза, жасмин, гвоздика. Шлейф завершается глубокими, обволакивающими нотами кедр, сандал, дубовый мох, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-6.jpg",
    gallery: ["perfume-7.jpg"],
    badges: [],
    rating: 4.7,
    reviewCount: 126,
    inStock: true,
    notes: {
      top: ["Цитрус", "Морские ноты"],
      heart: ["Роза", "Жасмин", "Гвоздика"],
      base: ["Кедр", "Сандал", "Дубовый мох"],
    },
    reviews: reviewsB,
    addedAt: "2026-02-16",
  },
  {
    slug: "pour-homme-versace",
    name: "POUR HOMME — Versace",
    price: 150000,
    short:
      "POUR HOMME от Versace — мужской аромат, где лимон раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "POUR HOMME — легендарное творение дома Versace, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот лимон, бергамот, мандарин, плавно перетекая в чувственное сердце из герань, кедр. Шлейф завершается глубокими, обволакивающими нотами мускус, дубовый мох, тонка, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-7.jpg",
    gallery: ["perfume-8.jpg"],
    badges: ["NEW"],
    rating: 4.8,
    reviewCount: 133,
    inStock: true,
    notes: {
      top: ["Лимон", "Бергамот", "Мандарин"],
      heart: ["Герань", "Кедр"],
      base: ["Мускус", "Дубовый мох", "Тонка"],
    },
    reviews: reviewsA,
    addedAt: "2026-03-17",
  },
  {
    slug: "imagination-louis-vuitton",
    name: "IMAGINATION — Louis Vuitton",
    price: 150000,
    short:
      "IMAGINATION от Louis Vuitton — мужской аромат, где белый мускус раскрывается в тёплой глубине кашемировое дерево. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "IMAGINATION — легендарное творение дома Louis Vuitton, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот белый мускус, плавно перетекая в чувственное сердце из амбретта, кориандр. Шлейф завершается глубокими, обволакивающими нотами кашемировое дерево, сандал, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-8.jpg",
    gallery: ["perfume-1.jpg"],
    badges: ["BEST SELLER"],
    rating: 4.9,
    reviewCount: 140,
    inStock: true,
    notes: {
      top: ["Белый мускус"],
      heart: ["Амбретта", "Кориандр"],
      base: ["Кашемировое дерево", "Сандал"],
    },
    reviews: reviewsB,
    addedAt: "2026-04-18",
  },
  {
    slug: "limmensite-louis-vuitton",
    name: "L'IMMENSITE — Louis Vuitton",
    price: 150000,
    short:
      "L'IMMENSITE от Louis Vuitton — мужской аромат, где зелёный мандарин раскрывается в тёплой глубине амбра. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "L'IMMENSITE — легендарное творение дома Louis Vuitton, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот зелёный мандарин, кардамон, плавно перетекая в чувственное сердце из морская лаванда, иланг-иланг. Шлейф завершается глубокими, обволакивающими нотами амбра, ветивер, сандал, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-1.jpg",
    gallery: ["perfume-2.jpg"],
    badges: ["LIMITED"],
    rating: 4.6,
    reviewCount: 147,
    inStock: true,
    notes: {
      top: ["Зелёный мандарин", "Кардамон"],
      heart: ["Морская лаванда", "Иланг-иланг"],
      base: ["Амбра", "Ветивер", "Сандал"],
    },
    reviews: reviewsA,
    addedAt: "2026-05-19",
  },
  {
    slug: "k-by-dolce-and-gabbana-dolce-and-gabbana",
    name: "K BY DOLCE & GABBANA — Dolce & Gabbana",
    price: 150000,
    short:
      "K BY DOLCE & GABBANA от Dolce & Gabbana — мужской аромат, где можжевельник раскрывается в тёплой глубине ветивер. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "K BY DOLCE & GABBANA — легендарное творение дома Dolce & Gabbana, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот можжевельник, грейпфрут, мандарин, плавно перетекая в чувственное сердце из кедровый лист, гальбанум. Шлейф завершается глубокими, обволакивающими нотами ветивер, пачули, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "men",
    image: "perfume-2.jpg",
    gallery: ["perfume-3.jpg"],
    badges: [],
    rating: 4.7,
    reviewCount: 154,
    inStock: false,
    notes: {
      top: ["Можжевельник", "Грейпфрут", "Мандарин"],
      heart: ["Кедровый лист", "Гальбанум"],
      base: ["Ветивер", "Пачули", "Мускус"],
    },
    reviews: reviewsB,
    addedAt: "2026-06-20",
  },
  {
    slug: "delina-exclusif-parfums-de-marly",
    name: "DELINA EXCLUSIF — Parfums de Marly",
    price: 150000,
    short:
      "DELINA EXCLUSIF от Parfums de Marly — женский аромат, где личи раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "DELINA EXCLUSIF — легендарное творение дома Parfums de Marly, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот личи, ревень, бергамот, плавно перетекая в чувственное сердце из пион, турецкая роза, ландыш. Шлейф завершается глубокими, обволакивающими нотами мускус, ваниль, кедр, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-3.jpg",
    gallery: ["perfume-4.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.8,
    reviewCount: 161,
    inStock: true,
    notes: {
      top: ["Личи", "Ревень", "Бергамот"],
      heart: ["Пион", "Турецкая роза", "Ландыш"],
      base: ["Мускус", "Ваниль", "Кедр"],
    },
    reviews: reviewsA,
    addedAt: "2026-07-21",
  },
  {
    slug: "mademoiselle-azzaro",
    name: "MADEMOISELLE — Azzaro",
    price: 150000,
    short:
      "MADEMOISELLE от Azzaro — женский аромат, где апельсин раскрывается в тёплой глубине пачули. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "MADEMOISELLE — легендарное творение дома Azzaro, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот апельсин, бергамот, розовый перец, плавно перетекая в чувственное сердце из жасмин, роза, пион. Шлейф завершается глубокими, обволакивающими нотами пачули, ваниль, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-4.jpg",
    gallery: ["perfume-5.jpg"],
    badges: ["NEW"],
    rating: 4.9,
    reviewCount: 168,
    inStock: true,
    notes: {
      top: ["Апельсин", "Бергамот", "Розовый перец"],
      heart: ["Жасмин", "Роза", "Пион"],
      base: ["Пачули", "Ваниль", "Мускус"],
    },
    reviews: reviewsB,
    addedAt: "2026-08-22",
  },
  {
    slug: "jadore-christian-dior",
    name: "J'ADORE — Christian Dior",
    price: 150000,
    short:
      "J'ADORE от Christian Dior — женский аромат, где иланг-иланг раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "J'ADORE — легендарное творение дома Christian Dior, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот иланг-иланг, бергамот, плавно перетекая в чувственное сердце из роза дамасская, жасмин самбак, орхидея. Шлейф завершается глубокими, обволакивающими нотами мускус, кедр, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-5.jpg",
    gallery: ["perfume-6.jpg"],
    badges: ["BEST SELLER"],
    rating: 4.6,
    reviewCount: 175,
    inStock: true,
    notes: {
      top: ["Иланг-иланг", "Бергамот"],
      heart: ["Роза Дамасская", "Жасмин Самбак", "Орхидея"],
      base: ["Мускус", "Кедр", "Амбра"],
    },
    reviews: reviewsA,
    addedAt: "2026-09-23",
  },
  {
    slug: "blackberry-and-bay-jo-malone",
    name: "BLACKBERRY & BAY — Jo Malone",
    price: 150000,
    short:
      "BLACKBERRY & BAY от Jo Malone — женский аромат, где ежевика раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "BLACKBERRY & BAY — легендарное творение дома Jo Malone, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот ежевика, лавровый лист, плавно перетекая в чувственное сердце из роза, инжирный лист. Шлейф завершается глубокими, обволакивающими нотами кедр, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-6.jpg",
    gallery: ["perfume-7.jpg"],
    badges: [],
    rating: 4.7,
    reviewCount: 182,
    inStock: true,
    notes: {
      top: ["Ежевика", "Лавровый лист"],
      heart: ["Роза", "Инжирный лист"],
      base: ["Кедр", "Мускус"],
    },
    reviews: reviewsB,
    addedAt: "2026-10-24",
  },
  {
    slug: "black-opium-yves-saint-laurent",
    name: "BLACK OPIUM — Yves Saint Laurent",
    price: 150000,
    short:
      "BLACK OPIUM от Yves Saint Laurent — женский аромат, где розовый перец раскрывается в тёплой глубине ваниль. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "BLACK OPIUM — легендарное творение дома Yves Saint Laurent, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот розовый перец, груша, апельсиновый цвет, плавно перетекая в чувственное сердце из кофе, жасмин самбак, миндаль. Шлейф завершается глубокими, обволакивающими нотами ваниль, пачули, кедр, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-7.jpg",
    gallery: ["perfume-8.jpg"],
    badges: ["BEST SELLER"],
    rating: 4.8,
    reviewCount: 189,
    inStock: true,
    notes: {
      top: ["Розовый перец", "Груша", "Апельсиновый цвет"],
      heart: ["Кофе", "Жасмин Самбак", "Миндаль"],
      base: ["Ваниль", "Пачули", "Кедр"],
    },
    reviews: reviewsA,
    addedAt: "2026-11-25",
  },
  {
    slug: "bright-crystal-versace",
    name: "BRIGHT CRYSTAL — Versace",
    price: 150000,
    short:
      "BRIGHT CRYSTAL от Versace — женский аромат, где гранат раскрывается в тёплой глубине амбра. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "BRIGHT CRYSTAL — легендарное творение дома Versace, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот гранат, юзу, ледяной аккорд, плавно перетекая в чувственное сердце из пион, магнолия, лотос. Шлейф завершается глубокими, обволакивающими нотами амбра, мускус, сандал, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-8.jpg",
    gallery: ["perfume-1.jpg"],
    badges: [],
    rating: 4.9,
    reviewCount: 36,
    inStock: true,
    notes: {
      top: ["Гранат", "Юзу", "Ледяной аккорд"],
      heart: ["Пион", "Магнолия", "Лотос"],
      base: ["Амбра", "Мускус", "Сандал"],
    },
    reviews: reviewsB,
    addedAt: "2026-12-26",
  },
  {
    slug: "light-blue-dolce-and-gabbana",
    name: "LIGHT BLUE — Dolce & Gabbana",
    price: 150000,
    short:
      "LIGHT BLUE от Dolce & Gabbana — женский аромат, где сицилийский лимон раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "LIGHT BLUE — легендарное творение дома Dolce & Gabbana, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот сицилийский лимон, яблоко, гранат, плавно перетекая в чувственное сердце из бамбук, жасмин, белая роза. Шлейф завершается глубокими, обволакивающими нотами кедр, амбра, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-1.jpg",
    gallery: ["perfume-2.jpg"],
    badges: ["NEW"],
    rating: 4.6,
    reviewCount: 43,
    inStock: true,
    notes: {
      top: ["Сицилийский лимон", "Яблоко", "Гранат"],
      heart: ["Бамбук", "Жасмин", "Белая роза"],
      base: ["Кедр", "Амбра", "Мускус"],
    },
    reviews: reviewsA,
    addedAt: "2026-01-27",
  },
  {
    slug: "miss-dior-christian-dior",
    name: "MISS DIOR — Christian Dior",
    price: 150000,
    short:
      "MISS DIOR от Christian Dior — женский аромат, где мандарин раскрывается в тёплой глубине пачули. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "MISS DIOR — легендарное творение дома Christian Dior, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот мандарин, розовый перец, плавно перетекая в чувственное сердце из роза гран крю, ландыш. Шлейф завершается глубокими, обволакивающими нотами пачули, мускус, розовое дерево, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-2.jpg",
    gallery: ["perfume-3.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.7,
    reviewCount: 50,
    inStock: true,
    notes: {
      top: ["Мандарин", "Розовый перец"],
      heart: ["Роза Гран Крю", "Ландыш"],
      base: ["Пачули", "Мускус", "Розовое дерево"],
    },
    reviews: reviewsB,
    addedAt: "2026-02-03",
  },
  {
    slug: "valaya-parfums-de-marly",
    name: "VALAYA — Parfums de Marly",
    price: 150000,
    short:
      "VALAYA от Parfums de Marly — женский аромат, где ваниль раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "VALAYA — легендарное творение дома Parfums de Marly, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот ваниль, клубника, ирис, плавно перетекая в чувственное сердце из жасмин, ландыш, гелиотроп. Шлейф завершается глубокими, обволакивающими нотами кедр, сандал, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-3.jpg",
    gallery: ["perfume-4.jpg"],
    badges: ["LIMITED"],
    rating: 4.8,
    reviewCount: 57,
    inStock: true,
    notes: {
      top: ["Ваниль", "Клубника", "Ирис"],
      heart: ["Жасмин", "Ландыш", "Гелиотроп"],
      base: ["Кедр", "Сандал", "Мускус"],
    },
    reviews: reviewsA,
    addedAt: "2026-03-04",
  },
  {
    slug: "play-for-her-givenchy",
    name: "PLAY FOR HER — Givenchy",
    price: 150000,
    short:
      "PLAY FOR HER от Givenchy — женский аромат, где персик раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "PLAY FOR HER — легендарное творение дома Givenchy, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот персик, груша, плавно перетекая в чувственное сердце из ирис, жасмин. Шлейф завершается глубокими, обволакивающими нотами мускус, сандал, ваниль, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "women",
    image: "perfume-4.jpg",
    gallery: ["perfume-5.jpg"],
    badges: ["BEST SELLER"],
    rating: 4.9,
    reviewCount: 64,
    inStock: true,
    notes: {
      top: ["Персик", "Груша"],
      heart: ["Ирис", "Жасмин"],
      base: ["Мускус", "Сандал", "Ваниль"],
    },
    reviews: reviewsB,
    addedAt: "2026-04-05",
  },
  {
    slug: "blue-talisman-ex-nihilo",
    name: "BLUE TALISMAN — Ex Nihilo",
    price: 150000,
    short:
      "BLUE TALISMAN от Ex Nihilo — унисекс аромат, где шафран раскрывается в тёплой глубине амбра. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "BLUE TALISMAN — легендарное творение дома Ex Nihilo, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот шафран, бергамот, плавно перетекая в чувственное сердце из ирис, роза. Шлейф завершается глубокими, обволакивающими нотами амбра, кожа, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-5.jpg",
    gallery: ["perfume-6.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.6,
    reviewCount: 71,
    inStock: true,
    notes: {
      top: ["Шафран", "Бергамот"],
      heart: ["Ирис", "Роза"],
      base: ["Амбра", "Кожа", "Мускус"],
    },
    reviews: reviewsA,
    addedAt: "2026-05-06",
  },
  {
    slug: "ganymede-marc-antoine-barrois",
    name: "GANYMEDE — Marc-Antoine Barrois",
    price: 150000,
    short:
      "GANYMEDE от Marc-Antoine Barrois — унисекс аромат, где кардамон раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "GANYMEDE — легендарное творение дома Marc-Antoine Barrois, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот кардамон, розовый перец, плавно перетекая в чувственное сердце из iso e super, фиалка. Шлейф завершается глубокими, обволакивающими нотами мускус, амбра, сандал, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-6.jpg",
    gallery: ["perfume-7.jpg"],
    badges: ["BEST SELLER"],
    rating: 4.7,
    reviewCount: 78,
    inStock: true,
    notes: {
      top: ["Кардамон", "Розовый перец"],
      heart: ["Iso E Super", "Фиалка"],
      base: ["Мускус", "Амбра", "Сандал"],
    },
    reviews: reviewsB,
    addedAt: "2026-06-07",
  },
  {
    slug: "montabaco-ormonde-jayne",
    name: "MONTABACO — Ormonde Jayne",
    price: 150000,
    short:
      "MONTABACO от Ormonde Jayne — унисекс аромат, где табачный лист раскрывается в тёплой глубине ваниль. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "MONTABACO — легендарное творение дома Ormonde Jayne, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот табачный лист, бергамот, плавно перетекая в чувственное сердце из кедр, пачули. Шлейф завершается глубокими, обволакивающими нотами ваниль, дубовый мох, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-7.jpg",
    gallery: ["perfume-8.jpg"],
    badges: [],
    rating: 4.8,
    reviewCount: 85,
    inStock: true,
    notes: {
      top: ["Табачный лист", "Бергамот"],
      heart: ["Кедр", "Пачули"],
      base: ["Ваниль", "Дубовый мох", "Амбра"],
    },
    reviews: reviewsA,
    addedAt: "2026-07-08",
  },
  {
    slug: "oud-wood-tom-ford",
    name: "OUD WOOD — Tom Ford",
    price: 150000,
    short:
      "OUD WOOD от Tom Ford — унисекс аромат, где розовое дерево раскрывается в тёплой глубине ваниль. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "OUD WOOD — легендарное творение дома Tom Ford, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот розовое дерево, кардамон, плавно перетекая в чувственное сердце из уд, сандал. Шлейф завершается глубокими, обволакивающими нотами ваниль, амбра, пачули, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-8.jpg",
    gallery: ["perfume-1.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.9,
    reviewCount: 92,
    inStock: true,
    notes: {
      top: ["Розовое дерево", "Кардамон"],
      heart: ["Уд", "Сандал"],
      base: ["Ваниль", "Амбра", "Пачули"],
    },
    reviews: reviewsB,
    addedAt: "2026-08-09",
  },
  {
    slug: "chocolate-greedy-montale",
    name: "CHOCOLATE GREEDY — Montale",
    price: 150000,
    short:
      "CHOCOLATE GREEDY от Montale — унисекс аромат, где какао раскрывается в тёплой глубине ваниль. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "CHOCOLATE GREEDY — легендарное творение дома Montale, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот какао, бергамот, плавно перетекая в чувственное сердце из пралине, миндаль. Шлейф завершается глубокими, обволакивающими нотами ваниль, тонка, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-1.jpg",
    gallery: ["perfume-2.jpg"],
    badges: [],
    rating: 4.6,
    reviewCount: 99,
    inStock: true,
    notes: {
      top: ["Какао", "Бергамот"],
      heart: ["Пралине", "Миндаль"],
      base: ["Ваниль", "Тонка", "Мускус"],
    },
    reviews: reviewsA,
    addedAt: "2026-09-10",
  },
  {
    slug: "soleil-de-capri-montale",
    name: "SOLEIL DE CAPRI — Montale",
    price: 150000,
    short:
      "SOLEIL DE CAPRI от Montale — унисекс аромат, где мандарин раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "SOLEIL DE CAPRI — легендарное творение дома Montale, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот мандарин, бергамот, плавно перетекая в чувственное сердце из жасмин, цветок апельсина. Шлейф завершается глубокими, обволакивающими нотами мускус, кедр, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-2.jpg",
    gallery: ["perfume-3.jpg"],
    badges: ["NEW"],
    rating: 4.7,
    reviewCount: 106,
    inStock: true,
    notes: {
      top: ["Мандарин", "Бергамот"],
      heart: ["Жасмин", "Цветок апельсина"],
      base: ["Мускус", "Кедр", "Амбра"],
    },
    reviews: reviewsB,
    addedAt: "2026-10-11",
  },
  {
    slug: "afternoon-swim-louis-vuitton",
    name: "AFTERNOON SWIM — Louis Vuitton",
    price: 150000,
    short:
      "AFTERNOON SWIM от Louis Vuitton — унисекс аромат, где морской аккорд раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "AFTERNOON SWIM — легендарное творение дома Louis Vuitton, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот морской аккорд, каламон, плавно перетекая в чувственное сердце из соль, водяная лилия. Шлейф завершается глубокими, обволакивающими нотами мускус, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-3.jpg",
    gallery: ["perfume-4.jpg"],
    badges: ["BEST SELLER"],
    rating: 4.8,
    reviewCount: 113,
    inStock: false,
    notes: {
      top: ["Морской аккорд", "Каламон"],
      heart: ["Соль", "Водяная лилия"],
      base: ["Мускус", "Амбра"],
    },
    reviews: reviewsA,
    addedAt: "2026-11-12",
  },
  {
    slug: "baccarat-rouge-540-maison-francis-kurkdjian",
    name: "BACCARAT ROUGE 540 — Maison Francis Kurkdjian",
    price: 150000,
    short:
      "BACCARAT ROUGE 540 от Maison Francis Kurkdjian — унисекс аромат, где шафран раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "BACCARAT ROUGE 540 — легендарное творение дома Maison Francis Kurkdjian, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот шафран, яблоко, плавно перетекая в чувственное сердце из жасмин, амбровое дерево. Шлейф завершается глубокими, обволакивающими нотами кедр, мускус, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-4.jpg",
    gallery: ["perfume-5.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.9,
    reviewCount: 120,
    inStock: true,
    notes: {
      top: ["Шафран", "Яблоко"],
      heart: ["Жасмин", "Амбровое дерево"],
      base: ["Кедр", "Мускус", "Амбра"],
    },
    reviews: reviewsB,
    addedAt: "2026-12-13",
  },
  {
    slug: "gypsy-water-byredo",
    name: "GYPSY WATER — Byredo",
    price: 150000,
    short:
      "GYPSY WATER от Byredo — унисекс аромат, где можжевельник раскрывается в тёплой глубине ваниль. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "GYPSY WATER — легендарное творение дома Byredo, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот можжевельник, бергамот, лимон, плавно перетекая в чувственное сердце из сосна, ладан, инжир. Шлейф завершается глубокими, обволакивающими нотами ваниль, амбра, сандал, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-5.jpg",
    gallery: ["perfume-6.jpg"],
    badges: [],
    rating: 4.6,
    reviewCount: 127,
    inStock: true,
    notes: {
      top: ["Можжевельник", "Бергамот", "Лимон"],
      heart: ["Сосна", "Ладан", "Инжир"],
      base: ["Ваниль", "Амбра", "Сандал"],
    },
    reviews: reviewsA,
    addedAt: "2026-01-14",
  },
  {
    slug: "tobacco-vanille-tom-ford",
    name: "TOBACCO VANILLE — Tom Ford",
    price: 150000,
    short:
      "TOBACCO VANILLE от Tom Ford — унисекс аромат, где табачный лист раскрывается в тёплой глубине сухие фрукты. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "TOBACCO VANILLE — легендарное творение дома Tom Ford, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот табачный лист, специи, плавно перетекая в чувственное сердце из ваниль, какао, тонка. Шлейф завершается глубокими, обволакивающими нотами сухие фрукты, древесные ноты, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-6.jpg",
    gallery: ["perfume-7.jpg"],
    badges: [],
    rating: 4.7,
    reviewCount: 134,
    inStock: true,
    notes: {
      top: ["Табачный лист", "Специи"],
      heart: ["Ваниль", "Какао", "Тонка"],
      base: ["Сухие фрукты", "Древесные ноты"],
    },
    reviews: reviewsB,
    addedAt: "2026-02-15",
  },
  {
    slug: "lost-cherry-tom-ford",
    name: "LOST CHERRY — Tom Ford",
    price: 150000,
    short:
      "LOST CHERRY от Tom Ford — унисекс аромат, где чёрная вишня раскрывается в тёплой глубине тонка. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "LOST CHERRY — легендарное творение дома Tom Ford, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот чёрная вишня, миндаль горький, плавно перетекая в чувственное сердце из турецкая роза, жасмин. Шлейф завершается глубокими, обволакивающими нотами тонка, пачули, ваниль, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-7.jpg",
    gallery: ["perfume-8.jpg"],
    badges: ["LIMITED"],
    rating: 4.8,
    reviewCount: 141,
    inStock: true,
    notes: {
      top: ["Чёрная вишня", "Миндаль горький"],
      heart: ["Турецкая роза", "Жасмин"],
      base: ["Тонка", "Пачули", "Ваниль"],
    },
    reviews: reviewsA,
    addedAt: "2026-03-16",
  },
  {
    slug: "megamare-orto-parisi",
    name: "MEGAMARE — Orto Parisi",
    price: 150000,
    short:
      "MEGAMARE от Orto Parisi — унисекс аромат, где морская вода раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "MEGAMARE — легендарное творение дома Orto Parisi, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот морская вода, кальцион, плавно перетекая в чувственное сердце из амбра серая, соль. Шлейф завершается глубокими, обволакивающими нотами мускус, древесные ноты, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-8.jpg",
    gallery: ["perfume-1.jpg"],
    badges: [],
    rating: 4.9,
    reviewCount: 148,
    inStock: true,
    notes: {
      top: ["Морская вода", "Кальцион"],
      heart: ["Амбра серая", "Соль"],
      base: ["Мускус", "Древесные ноты"],
    },
    reviews: reviewsB,
    addedAt: "2026-04-17",
  },
  {
    slug: "silver-mountain-water-creed",
    name: "SILVER MOUNTAIN WATER — Creed",
    price: 150000,
    short:
      "SILVER MOUNTAIN WATER от Creed — унисекс аромат, где зелёный чай раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "SILVER MOUNTAIN WATER — легендарное творение дома Creed, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот зелёный чай, мандарин, плавно перетекая в чувственное сердце из чёрная смородина, малина. Шлейф завершается глубокими, обволакивающими нотами мускус, сандал, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-1.jpg",
    gallery: ["perfume-2.jpg"],
    badges: [],
    rating: 4.6,
    reviewCount: 155,
    inStock: true,
    notes: {
      top: ["Зелёный чай", "Мандарин"],
      heart: ["Чёрная смородина", "Малина"],
      base: ["Мускус", "Сандал", "Амбра"],
    },
    reviews: reviewsA,
    addedAt: "2026-05-18",
  },
  {
    slug: "erba-pura-sospiro",
    name: "ERBA PURA — Sospiro",
    price: 150000,
    short:
      "ERBA PURA от Sospiro — унисекс аромат, где красные ягоды раскрывается в тёплой глубине ваниль. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "ERBA PURA — легендарное творение дома Sospiro, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот красные ягоды, цитрус, плавно перетекая в чувственное сердце из персик, дыня. Шлейф завершается глубокими, обволакивающими нотами ваниль, мускус, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-2.jpg",
    gallery: ["perfume-3.jpg"],
    badges: [],
    rating: 4.7,
    reviewCount: 162,
    inStock: true,
    notes: {
      top: ["Красные ягоды", "Цитрус"],
      heart: ["Персик", "Дыня"],
      base: ["Ваниль", "Мускус", "Амбра"],
    },
    reviews: reviewsB,
    addedAt: "2026-06-19",
  },
  {
    slug: "mandarino-di-amalfi-tom-ford",
    name: "MANDARINO DI AMALFI — Tom Ford",
    price: 150000,
    short:
      "MANDARINO DI AMALFI от Tom Ford — унисекс аромат, где мандарин раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "MANDARINO DI AMALFI — легендарное творение дома Tom Ford, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот мандарин, петитгрейн, плавно перетекая в чувственное сердце из флёрдоранж, ветивер. Шлейф завершается глубокими, обволакивающими нотами кедр, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-3.jpg",
    gallery: ["perfume-4.jpg"],
    badges: [],
    rating: 4.8,
    reviewCount: 169,
    inStock: true,
    notes: {
      top: ["Мандарин", "Петитгрейн"],
      heart: ["Флёрдоранж", "Ветивер"],
      base: ["Кедр", "Амбра"],
    },
    reviews: reviewsA,
    addedAt: "2026-07-20",
  },
  {
    slug: "cedrat-boise-mancera",
    name: "CEDRAT BOISE — Mancera",
    price: 150000,
    short:
      "CEDRAT BOISE от Mancera — унисекс аромат, где цитрон раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "CEDRAT BOISE — легендарное творение дома Mancera, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот цитрон, бергамот, плавно перетекая в чувственное сердце из кардамон, шафран. Шлейф завершается глубокими, обволакивающими нотами кедр, амбра, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-4.jpg",
    gallery: ["perfume-5.jpg"],
    badges: [],
    rating: 4.9,
    reviewCount: 176,
    inStock: true,
    notes: {
      top: ["Цитрон", "Бергамот"],
      heart: ["Кардамон", "Шафран"],
      base: ["Кедр", "Амбра", "Мускус"],
    },
    reviews: reviewsB,
    addedAt: "2026-08-21",
  },
  {
    slug: "black-afgano-nasomatto",
    name: "BLACK AFGANO — Nasomatto",
    price: 150000,
    short:
      "BLACK AFGANO от Nasomatto — унисекс аромат, где конопляный аккорд раскрывается в тёплой глубине пачули. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "BLACK AFGANO — легендарное творение дома Nasomatto, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот конопляный аккорд, специи, плавно перетекая в чувственное сердце из кофе, ладан. Шлейф завершается глубокими, обволакивающими нотами пачули, табак, ваниль, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-5.jpg",
    gallery: ["perfume-6.jpg"],
    badges: ["LIMITED"],
    rating: 4.6,
    reviewCount: 183,
    inStock: true,
    notes: {
      top: ["Конопляный аккорд", "Специи"],
      heart: ["Кофе", "Ладан"],
      base: ["Пачули", "Табак", "Ваниль"],
    },
    reviews: reviewsA,
    addedAt: "2026-09-22",
  },
  {
    slug: "mojave-ghost-byredo",
    name: "MOJAVE GHOST — Byredo",
    price: 150000,
    short:
      "MOJAVE GHOST от Byredo — унисекс аромат, где амбретта раскрывается в тёплой глубине мускус. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "MOJAVE GHOST — легендарное творение дома Byredo, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот амбретта, мускус, плавно перетекая в чувственное сердце из сандал, бумажная древесина. Шлейф завершается глубокими, обволакивающими нотами мускус, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-6.jpg",
    gallery: ["perfume-7.jpg"],
    badges: [],
    rating: 4.7,
    reviewCount: 190,
    inStock: true,
    notes: {
      top: ["Амбретта", "Мускус"],
      heart: ["Сандал", "Бумажная древесина"],
      base: ["Мускус", "Амбра"],
    },
    reviews: reviewsB,
    addedAt: "2026-10-23",
  },
  {
    slug: "amber-wood-ajmal",
    name: "AMBER WOOD — Ajmal",
    price: 150000,
    short:
      "AMBER WOOD от Ajmal — унисекс аромат, где специи раскрывается в тёплой глубине сандал. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "AMBER WOOD — легендарное творение дома Ajmal, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот специи, бергамот, плавно перетекая в чувственное сердце из уд, амбра. Шлейф завершается глубокими, обволакивающими нотами сандал, мускус, ваниль, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-7.jpg",
    gallery: ["perfume-8.jpg"],
    badges: [],
    rating: 4.8,
    reviewCount: 37,
    inStock: true,
    notes: {
      top: ["Специи", "Бергамот"],
      heart: ["Уд", "Амбра"],
      base: ["Сандал", "Мускус", "Ваниль"],
    },
    reviews: reviewsA,
    addedAt: "2026-11-24",
  },
  {
    slug: "kirke-tiziana-terenzi",
    name: "KIRKE — Tiziana Terenzi",
    price: 150000,
    short:
      "KIRKE от Tiziana Terenzi — унисекс аромат, где кокос раскрывается в тёплой глубине тонка. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "KIRKE — легендарное творение дома Tiziana Terenzi, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот кокос, иланг-иланг, плавно перетекая в чувственное сердце из ваниль, пачули. Шлейф завершается глубокими, обволакивающими нотами тонка, сандал, амбра, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-8.jpg",
    gallery: ["perfume-1.jpg"],
    badges: ["EXCLUSIVE"],
    rating: 4.9,
    reviewCount: 44,
    inStock: true,
    notes: {
      top: ["Кокос", "Иланг-иланг"],
      heart: ["Ваниль", "Пачули"],
      base: ["Тонка", "Сандал", "Амбра"],
    },
    reviews: reviewsB,
    addedAt: "2026-12-25",
  },
  {
    slug: "molecule-02-escentric-molecules",
    name: "MOLECULE 02 — Escentric Molecules",
    price: 150000,
    short:
      "MOLECULE 02 от Escentric Molecules — унисекс аромат, где амброксан раскрывается в тёплой глубине амброксан. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "MOLECULE 02 — легендарное творение дома Escentric Molecules, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот амброксан, плавно перетекая в чувственное сердце из амброксан. Шлейф завершается глубокими, обволакивающими нотами амброксан, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-1.jpg",
    gallery: ["perfume-2.jpg"],
    badges: ["NEW"],
    rating: 4.6,
    reviewCount: 51,
    inStock: true,
    notes: {
      top: ["Амброксан"],
      heart: ["Амброксан"],
      base: ["Амброксан"],
    },
    reviews: reviewsA,
    addedAt: "2026-01-26",
  },
  {
    slug: "marfa-memo-paris",
    name: "MARFA — Memo Paris",
    price: 150000,
    short:
      "MARFA от Memo Paris — унисекс аромат, где лаванда раскрывается в тёплой глубине кедр. Изысканная композиция для тех, кто ценит характер и утончённость.",
    description:
      "MARFA — легендарное творение дома Memo Paris, воплощение элегантности и характера. Композиция открывается свежим аккордом из нот лаванда, бергамот, плавно перетекая в чувственное сердце из ирис, розмарин. Шлейф завершается глубокими, обволакивающими нотами кедр, амбра, мускус, оставляя незабываемый след и подчёркивая безупречный вкус своего обладателя. Идеальный выбор для тех, кто не боится выделяться.",
    category: "unisex",
    image: "perfume-2.jpg",
    gallery: ["perfume-3.jpg"],
    badges: [],
    rating: 4.7,
    reviewCount: 58,
    inStock: true,
    notes: {
      top: ["Лаванда", "Бергамот"],
      heart: ["Ирис", "Розмарин"],
      base: ["Кедр", "Амбра", "Мускус"],
    },
    reviews: reviewsB,
    addedAt: "2026-02-27",
  },
];

/* =====================================================================
 *  Below this line is site plumbing — you do not need to edit it.
 * ===================================================================== */

export interface Product {
  slug: string;
  name: string;
  category: Category;
  tags: Tag[];
  short: string;
  description: string;
  price: number;
  rating: number;
  reviewCount: number;
  images: string[];
  notes: { top: string[]; heart: string[]; base: string[] };
  inStock: boolean;
  addedAt: string;
  featured: number;
  reviews: Review[];
}

export const PRODUCTS: Product[] = PRODUCT_LIST.map((p, i) => ({
  slug: p.slug,
  name: p.name,
  category: p.category,
  tags: p.badges ?? [],
  short: p.short,
  description: p.description,
  price: p.price,
  rating: p.rating,
  reviewCount: p.reviewCount,
  images: [p.image, ...(p.gallery ?? [])]
    .map(productImage)
    .filter((url) => url !== ""),
  notes: p.notes ?? { top: [], heart: [], base: [] },
  inStock: p.inStock ?? true,
  addedAt: p.addedAt ?? "2026-01-01",
  featured: i + 1,
  reviews: p.reviews ?? [],
}));

export const priceFor = (product: Product, size: SizeML) =>
  Math.round(product.price * SIZE_MULTIPLIER[size] * 100) / 100;

export const getProduct = (slug: string) =>
  PRODUCTS.find((p) => p.slug === slug);

export const bestSellers = () =>
  PRODUCTS.filter((p) => p.tags.includes("BEST SELLER"));
