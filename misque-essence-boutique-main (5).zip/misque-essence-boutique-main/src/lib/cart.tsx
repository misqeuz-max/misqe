import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from "react";
import { SITE } from "@/config/site";
import { PRODUCTS, priceFor, type Product, type SizeML } from "@/data/products";

export interface CartLine {
  slug: string;
  size: SizeML;
  qty: number;
}

export interface CartLineView extends CartLine {
  product: Product;
  unitPrice: number;
  lineTotal: number;
}

interface CartValue {
  lines: CartLine[];
  items: CartLineView[];
  count: number;
  subtotal: number;
  delivery: number;
  total: number;
  add: (slug: string, size: SizeML, qty?: number) => void;
  remove: (slug: string, size: SizeML) => void;
  setQty: (slug: string, size: SizeML, qty: number) => void;
  clear: () => void;
  favorites: string[];
  toggleFavorite: (slug: string) => void;
}

const CartContext = createContext<CartValue | null>(null);
const CART_KEY = "misqe.cart.v1";
const FAV_KEY = "misqe.favorites.v1";

export function CartProvider({ children }: { children: ReactNode }) {
  const [lines, setLines] = useState<CartLine[]>([]);
  const [favorites, setFavorites] = useState<string[]>([]);
  const [ready, setReady] = useState(false);

  useEffect(() => {
    try {
      const c = localStorage.getItem(CART_KEY);
      if (c) setLines(JSON.parse(c));
      const f = localStorage.getItem(FAV_KEY);
      if (f) setFavorites(JSON.parse(f));
    } catch {
      /* ignore corrupted storage */
    }
    setReady(true);
  }, []);

  useEffect(() => {
    if (ready) localStorage.setItem(CART_KEY, JSON.stringify(lines));
  }, [lines, ready]);

  useEffect(() => {
    if (ready) localStorage.setItem(FAV_KEY, JSON.stringify(favorites));
  }, [favorites, ready]);

  const add = useCallback((slug: string, size: SizeML, qty = 1) => {
    setLines((prev) => {
      const i = prev.findIndex((l) => l.slug === slug && l.size === size);
      if (i === -1) return [...prev, { slug, size, qty }];
      return prev.map((l, idx) => (idx === i ? { ...l, qty: l.qty + qty } : l));
    });
  }, []);

  const remove = useCallback((slug: string, size: SizeML) => {
    setLines((prev) => prev.filter((l) => !(l.slug === slug && l.size === size)));
  }, []);

  const setQty = useCallback((slug: string, size: SizeML, qty: number) => {
    setLines((prev) =>
      qty <= 0
        ? prev.filter((l) => !(l.slug === slug && l.size === size))
        : prev.map((l) =>
            l.slug === slug && l.size === size ? { ...l, qty } : l,
          ),
    );
  }, []);

  const clear = useCallback(() => setLines([]), []);

  const toggleFavorite = useCallback((slug: string) => {
    setFavorites((prev) =>
      prev.includes(slug) ? prev.filter((s) => s !== slug) : [...prev, slug],
    );
  }, []);

  const value = useMemo<CartValue>(() => {
    const items: CartLineView[] = lines.flatMap((l) => {
      const product = PRODUCTS.find((p) => p.slug === l.slug);
      if (!product) return [];
      const unitPrice = priceFor(product, l.size);
      return [{ ...l, product, unitPrice, lineTotal: unitPrice * l.qty }];
    });
    const subtotal = items.reduce((s, i) => s + i.lineTotal, 0);
    const delivery =
      subtotal === 0 || subtotal >= SITE.freeDeliveryOver ? 0 : SITE.deliveryFee;
    return {
      lines,
      items,
      count: items.reduce((s, i) => s + i.qty, 0),
      subtotal,
      delivery,
      total: subtotal + delivery,
      add,
      remove,
      setQty,
      clear,
      favorites,
      toggleFavorite,
    };
  }, [lines, favorites, add, remove, setQty, clear, toggleFavorite]);

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error("useCart must be used within CartProvider");
  return ctx;
}
