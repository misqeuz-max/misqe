import { SITE, money, telegramUrl } from "@/config/site";
import type { CartLineView } from "@/lib/cart";

export interface OrderDetails {
  name?: string | undefined;
  phone?: string | undefined;
  city?: string | undefined;
  address?: string | undefined;
  delivery?: string | undefined;
  notes?: string | undefined;
}

/** Builds the Telegram order message and returns a ready-to-open t.me link. */
export function buildTelegramOrder(
  items: CartLineView[],
  total: number,
  details: OrderDetails = {},
) {
  const lines = [
    `NEW ORDER — ${SITE.brand}`,
    "",
    ...(details.name ? [`Name: ${details.name}`] : []),
    ...(details.phone ? [`Phone: ${details.phone}`] : []),
    ...(details.city || details.address
      ? [`Address: ${[details.address, details.city].filter(Boolean).join(", ")}`]
      : []),
    ...(details.delivery ? [`Delivery: ${details.delivery}`] : []),
    "",
    "Products:",
    ...items.map(
      (i) =>
        `• ${i.product.name} — ${i.size}ml × ${i.qty} — ${money(i.lineTotal)}`,
    ),
    "",
    `Total: ${money(total)}`,
    ...(details.notes ? ["", `Notes: ${details.notes}`] : []),
  ];
  return telegramUrl(lines.join("\n"));
}

export const telegramEnquiryUrl = (productName?: string) =>
  telegramUrl(
    productName
      ? `Hello ${SITE.brand}, I would like to order: ${productName}`
      : `Hello ${SITE.brand}, I would like to place an order.`,
  );
