import { useEffect, useState } from "react";
import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Menu, Search, ShoppingBag, User, X } from "lucide-react";
import { Logo } from "@/components/Logo";
import { LanguageSwitcher } from "@/components/LanguageSwitcher";
import { useCart } from "@/lib/cart";
import { useT } from "@/lib/i18n";
import { PRODUCTS } from "@/data/products";
import { money } from "@/config/site";
import { cn } from "@/lib/utils";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Sheet, SheetContent, SheetTitle } from "@/components/ui/sheet";
import { Input } from "@/components/ui/input";

const NAV = [
  { key: "nav.home", label: "Home", to: "/", search: undefined },
  { key: "nav.shop", label: "Shop", to: "/shop", search: {} },
  { key: "nav.men", label: "Men", to: "/shop", search: { category: "men" } },
  { key: "nav.women", label: "Women", to: "/shop", search: { category: "women" } },
  { key: "nav.unisex", label: "Unisex", to: "/shop", search: { category: "unisex" } },
  { key: "nav.best", label: "Best Sellers", to: "/shop", search: { category: "best" } },
  { key: "nav.about", label: "About", to: "/about", search: undefined },
  { key: "nav.contact", label: "Contact", to: "/contact", search: undefined },
] as const;

export function Header() {
  const t = useT();
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [q, setQ] = useState("");
  const { count } = useCart();
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => setMenuOpen(false), [pathname]);

  const results = q.trim()
    ? PRODUCTS.filter((p) =>
        `${p.name} ${p.category} ${p.short}`
          .toLowerCase()
          .includes(q.trim().toLowerCase()),
      ).slice(0, 6)
    : [];

  return (
    <>
      <header
        className={cn(
          "fixed inset-x-0 top-0 z-50 transition-all duration-500",
          scrolled
            ? "border-b border-border/60 bg-onyx/90 backdrop-blur-xl"
            : "bg-gradient-to-b from-onyx/80 to-transparent",
        )}
      >
        <div className="mx-auto flex h-20 max-w-7xl items-center justify-between gap-4 px-4 sm:px-6 lg:px-10">
          <div className="flex items-center gap-3">
            <button
              type="button"
              aria-label={t("header.openMenu", "Open menu")}
              onClick={() => setMenuOpen(true)}
              className="-ml-2 p-2 text-ivory/80 transition-colors hover:text-gold lg:hidden"
            >
              <Menu className="h-5 w-5" />
            </button>
            <Logo />
          </div>

          <nav className="hidden items-center gap-7 lg:flex">
            {NAV.map((item) => (
              <Link
                key={item.key}
                to={item.to}
                search={item.search as never}
                className="text-[0.7rem] tracking-[0.2em] text-ivory/75 uppercase transition-colors duration-300 hover:text-gold"
                activeOptions={{ exact: item.to === "/" }}
                activeProps={{ className: "text-gold" }}
              >
                {t(item.key, item.label)}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-1 sm:gap-2">
            <LanguageSwitcher />
            <button
              type="button"
              aria-label={t("header.search", "Search")}
              onClick={() => setSearchOpen(true)}
              className="p-2 text-ivory/80 transition-colors hover:text-gold"
            >
              <Search className="h-[1.05rem] w-[1.05rem]" />
            </button>
            <Link
              to="/contact"
              aria-label={t("header.account", "Account")}
              className="p-2 text-ivory/80 transition-colors hover:text-gold"
            >
              <User className="h-[1.05rem] w-[1.05rem]" />
            </Link>
            <Link
              to="/cart"
              aria-label={t("header.shoppingBag", "Shopping bag")}
              className="relative p-2 text-ivory/80 transition-colors hover:text-gold"
            >
              <ShoppingBag className="h-[1.05rem] w-[1.05rem]" />
              {count > 0 && (
                <span className="absolute top-0 right-0 flex h-4 min-w-4 items-center justify-center rounded-full bg-gold px-1 text-[0.6rem] font-medium text-primary-foreground">
                  {count}
                </span>
              )}
            </Link>
          </div>
        </div>
      </header>

      {/* Mobile menu */}
      <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
        <SheetContent
          side="left"
          className="w-[86vw] max-w-sm border-border/60 bg-onyx p-0"
        >
          <SheetTitle className="sr-only">{t("header.menu", "Menu")}</SheetTitle>
          <div className="flex h-20 items-center justify-between border-b border-border/60 px-6">
            <Logo size="sm" />
            <button
              type="button"
              aria-label={t("header.closeMenu", "Close menu")}
              onClick={() => setMenuOpen(false)}
              className="p-2 text-ivory/70 hover:text-gold"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
          <nav className="flex flex-col px-6 py-6">
            <div className="flex items-center justify-between border-b border-border/40 py-4">
              <span className="text-[0.65rem] tracking-luxe text-muted-foreground uppercase">
                {t("header.language", "Language")}
              </span>
              <LanguageSwitcher />
            </div>
            {NAV.map((item) => (
              <Link
                key={item.key}
                to={item.to}
                search={item.search as never}
                className="border-b border-border/40 py-4 font-serif text-2xl text-ivory transition-colors hover:text-gold"
              >
                {t(item.key, item.label)}
              </Link>
            ))}
          </nav>
        </SheetContent>
      </Sheet>

      {/* Search */}
      <Dialog open={searchOpen} onOpenChange={setSearchOpen}>
        <DialogContent className="top-24 max-w-xl translate-y-0 border-border/60 bg-card">
          <DialogHeader>
            <DialogTitle className="font-serif text-2xl font-light">
              {t("header.searchTitle", "Search the collection")}
            </DialogTitle>
          </DialogHeader>
          <Input
            autoFocus
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder={t(
              "header.searchPlaceholder",
              "Search perfumes, notes, categories…",
            )}
            className="h-12 border-border/60 bg-background text-base"
            onKeyDown={(e) => {
              if (e.key === "Enter" && results[0]) {
                setSearchOpen(false);
                navigate({
                  to: "/product/$slug",
                  params: { slug: results[0].slug },
                });
              }
            }}
          />
          <div className="max-h-80 overflow-y-auto">
            {results.map((p) => (
              <Link
                key={p.slug}
                to="/product/$slug"
                params={{ slug: p.slug }}
                onClick={() => setSearchOpen(false)}
                className="flex items-center gap-4 border-b border-border/40 py-3 transition-colors hover:bg-secondary/60"
              >
                <img
                  src={p.images[0]}
                  alt={p.name}
                  loading="lazy"
                  className="h-14 w-14 object-cover"
                />
                <span className="flex-1">
                  <span className="block font-serif text-lg">{p.name}</span>
                  <span className="block text-xs tracking-widest text-muted-foreground uppercase">
                    {t(`category.${p.category}`, p.category)}
                  </span>
                </span>
                <span className="text-sm text-gold">{money(p.price)}</span>
              </Link>
            ))}
            {q.trim() && results.length === 0 && (
              <p className="py-6 text-center text-sm text-muted-foreground">
                {t("header.noResults", "No fragrances match “{q}”.").replace(
                  "{q}",
                  q,
                )}
              </p>
            )}
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
