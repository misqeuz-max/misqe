import { Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { buildTelegramOrder, telegramEnquiryUrl, type OrderDetails } from "@/lib/telegram";
import { useCart } from "@/lib/cart";
import { useT } from "@/lib/i18n";

/**
 * "ORDER VIA TELEGRAM" button.
 * With a cart it sends the full order; otherwise a simple enquiry.
 * The username lives in src/config/site.ts.
 */
export function TelegramOrderButton({
  details,
  productName,
  className,
  variant = "telegram",
  size = "xl",
}: {
  details?: OrderDetails;
  productName?: string;
  className?: string;
  variant?: "telegram" | "gold" | "outlineGold";
  size?: "default" | "lg" | "xl";
}) {
  const t = useT();
  const { items, total } = useCart();
  const href =
    items.length > 0
      ? buildTelegramOrder(items, total, details ?? {})
      : telegramEnquiryUrl(productName);

  return (
    <Button asChild variant={variant} size={size} className={className}>
      <a href={href} target="_blank" rel="noreferrer">
        <Send className="h-4 w-4" />
        {t("telegram.orderViaTelegram", "Order via Telegram")}
      </a>
    </Button>
  );
}
