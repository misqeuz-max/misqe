import { Star } from "lucide-react";
import { cn } from "@/lib/utils";
import { useT } from "@/lib/i18n";

export function StarRating({
  rating,
  className,
  size = 14,
}: {
  rating: number;
  className?: string;
  size?: number;
}) {
  const t = useT();
  return (
    <span
      className={cn("inline-flex items-center gap-0.5", className)}
      aria-label={t("common.rated", "Rated {rating} out of 5").replace(
        "{rating}",
        String(rating),
      )}
    >
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          width={size}
          height={size}
          className={cn(
            "shrink-0",
            i <= Math.round(rating)
              ? "fill-gold text-gold"
              : "text-muted-foreground/50",
          )}
        />
      ))}
    </span>
  );
}
