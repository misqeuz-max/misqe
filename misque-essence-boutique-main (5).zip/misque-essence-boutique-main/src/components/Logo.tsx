import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

/**
 * MISQÉ PARFUM brand mark.
 *
 * To use an uploaded logo file instead of the wordmark:
 * 1. put the file in src/assets/ (e.g. logo.png)
 * 2. import it here:  import logo from "@/assets/logo.png";
 * 3. replace the <span> block below with:
 *    <img src={logo} alt="MISQÉ PARFUM" className="h-9 w-auto" />
 * Nothing else in the site needs to change.
 */
export function Logo({
  className,
  size = "md",
}: {
  className?: string;
  size?: "sm" | "md" | "lg";
}) {
  const scale = {
    sm: "text-base",
    md: "text-xl md:text-2xl",
    lg: "text-3xl md:text-4xl",
  }[size];

  return (
    <Link to="/" aria-label="MISQÉ PARFUM — home" className={cn("group inline-flex flex-col items-center leading-none", className)}>
      <span
        className={cn(
          "font-serif tracking-[0.22em] text-gold-gradient transition-opacity duration-500 group-hover:opacity-80",
          scale,
        )}
      >
        MISQÉ
      </span>
      <span className="mt-1 text-[0.5rem] tracking-luxe text-ivory/70 md:text-[0.55rem]">
        PARFUM
      </span>
    </Link>
  );
}
