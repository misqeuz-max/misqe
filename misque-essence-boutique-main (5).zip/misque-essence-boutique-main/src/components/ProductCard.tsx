import { useState } from "react";
import { Link } from "@tanstack/react-router";
import { Eye, Heart, ShoppingBag } from "lucide-react";
import { toast } from "sonner";
import { StarRating } from "@/components/StarRating";
import { SizeSelector } from "@/components/SizeSelector";
import { useCart } from "@/lib/cart";
import { money } from "@/config/site";
import { priceFor, type Product, type SizeML } from "@/data/products";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogTitle,
} from "@/components/ui/dialog";

export function ProductCard({ product }: { product: Product }) {
  const { add, favorites, toggleFavorite } = useCart();
  const [quickView, setQuickView] = useState(false);
  const [size, setSize] = useState<SizeML>(50);
  const isFav = favorites.includes(product.slug);

  const addToCart = (s: SizeML = 50) => {
    add(product.slug, s, 1);
    toast.success(`${product.name} · ${s}ml added to your bag`);
  };

  return (
    <>
      <article className="group relative flex flex-col">
        <div className="relative overflow-hidden bg-onyx">
          <Link to="/product/$slug" params={{ slug: product.slug }}>
            <img
              src={product.images[0]}
              alt={`${product.name} perfume bottle`}
              loading="lazy"
              width={1024}
              height={1280}
              className="aspect-4/5 w-full object-contain p-4 transition-transform duration-[900ms] ease-out group-hover:scale-105"
            />
          </Link>

          <div className="pointer-events-none absolute top-4 left-4 flex flex-col gap-2">
            {product.tags.map((t) => (
              <span
                key={t}
                className="border border-gold/50 bg-onyx/70 px-2.5 py-1 text-[0.55rem] tracking-luxe text-gold uppercase backdrop-blur-sm"
              >
                {t}
              </span>
            ))}
          </div>

          <button
            type="button"
            aria-label={isFav ? "Remove from favourites" : "Add to favourites"}
            onClick={() => toggleFavorite(product.slug)}
            className="absolute top-4 right-4 flex h-9 w-9 items-center justify-center border border-border/60 bg-onyx/60 backdrop-blur-sm transition-colors hover:border-gold"
          >
            <Heart
              className={cn(
                "h-4 w-4 transition-colors",
                isFav ? "fill-gold text-gold" : "text-ivory/70",
              )}
            />
          </button>

          <div className="absolute inset-x-0 bottom-0 flex translate-y-full gap-px opacity-0 transition-all duration-500 group-hover:translate-y-0 group-hover:opacity-100">
            <button
              type="button"
              onClick={() => addToCart(50)}
              disabled={!product.inStock}
              className="flex flex-1 items-center justify-center gap-2 bg-gold/95 py-3 text-[0.6rem] tracking-luxe text-primary-foreground uppercase transition-colors hover:bg-gold disabled:opacity-40"
            >
              <ShoppingBag className="h-3.5 w-3.5" />
              {product.inStock ? "Add to Cart" : "Sold out"}
            </button>
            <button
              type="button"
              onClick={() => setQuickView(true)}
              className="flex items-center justify-center gap-2 bg-onyx/90 px-4 py-3 text-[0.6rem] tracking-luxe text-ivory uppercase transition-colors hover:text-gold"
            >
              <Eye className="h-3.5 w-3.5" />
              Quick View
            </button>
          </div>
        </div>

        <div className="flex flex-1 flex-col pt-5">
          <span className="text-[0.55rem] tracking-luxe text-muted-foreground uppercase">
            {product.category}
          </span>
          <h3 className="mt-2 font-serif text-2xl leading-tight">
            <Link
              to="/product/$slug"
              params={{ slug: product.slug }}
              className="transition-colors hover:text-gold"
            >
              {product.name}
            </Link>
          </h3>
          <p className="mt-2 line-clamp-2 text-sm leading-relaxed text-muted-foreground">
            {product.short}
          </p>
          <div className="mt-3 flex items-center gap-2">
            <StarRating rating={product.rating} />
            <span className="text-xs text-muted-foreground">
              {product.rating.toFixed(1)} ({product.reviewCount})
            </span>
          </div>
          <p className="mt-3 text-lg text-gold">{money(product.price)}</p>
          <div className="mt-4 sm:hidden">
            <Button
              variant="gold"
              size="sm"
              className="w-full"
              disabled={!product.inStock}
              onClick={() => addToCart(50)}
            >
              {product.inStock ? "Add to Cart" : "Sold out"}
            </Button>
          </div>
        </div>
      </article>

      <Dialog open={quickView} onOpenChange={setQuickView}>
        <DialogContent className="max-w-3xl border-border/60 bg-card p-0">
          <DialogTitle className="sr-only">{product.name}</DialogTitle>
          <div className="grid md:grid-cols-2">
            <img
              src={product.images[0]}
              alt={product.name}
              loading="lazy"
              className="h-full max-h-[70vh] w-full bg-onyx object-contain p-6"
            />
            <div className="p-8">
              <span className="text-[0.55rem] tracking-luxe text-muted-foreground uppercase">
                {product.category}
              </span>
              <h3 className="mt-2 font-serif text-3xl">{product.name}</h3>
              <div className="mt-3 flex items-center gap-2">
                <StarRating rating={product.rating} />
                <span className="text-xs text-muted-foreground">
                  {product.reviewCount} reviews
                </span>
              </div>
              <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
                {product.description}
              </p>
              <div className="mt-6">
                <SizeSelector value={size} onChange={setSize} product={product} />
              </div>
              <p className="mt-6 font-serif text-3xl text-gold">
                {money(priceFor(product, size))}
              </p>
              <div className="mt-6 flex flex-col gap-3">
                <Button
                  variant="gold"
                  disabled={!product.inStock}
                  onClick={() => {
                    addToCart(size);
                    setQuickView(false);
                  }}
                >
                  Add to Cart
                </Button>
                <Button variant="outlineGold" asChild>
                  <Link to="/product/$slug" params={{ slug: product.slug }}>
                    View full details
                  </Link>
                </Button>
              </div>
            </div>
          </div>
        </DialogContent>
      </Dialog>
    </>
  );
}
