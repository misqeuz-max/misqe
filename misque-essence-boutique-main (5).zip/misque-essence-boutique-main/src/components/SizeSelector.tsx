import { money } from "@/config/site";
import { priceFor, type Product, type SizeML } from "@/data/products";
import { cn } from "@/lib/utils";
import { useT } from "@/lib/i18n";

const SIZES: SizeML[] = [10, 30, 50];

export function SizeSelector({
  product,
  value,
  onChange,
}: {
  product: Product;
  value: SizeML;
  onChange: (s: SizeML) => void;
}) {
  const t = useT();
  return (
    <div>
      <p className="mb-3 text-[0.6rem] tracking-luxe text-muted-foreground uppercase">
        {t("size.size", "Size")}
      </p>
      <div className="flex flex-wrap gap-3">
        {SIZES.map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => onChange(s)}
            className={cn(
              "min-w-24 border px-4 py-3 text-left transition-all duration-300",
              value === s
                ? "border-gold bg-gold/10"
                : "border-border/60 hover:border-gold/60",
            )}
          >
            <span className="block text-sm text-ivory">{s}ml</span>
            <span className="block text-xs text-muted-foreground">
              {money(priceFor(product, s))}
            </span>
          </button>
        ))}
      </div>
    </div>
  );
}
