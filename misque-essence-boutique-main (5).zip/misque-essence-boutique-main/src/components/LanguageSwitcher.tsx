import { Globe } from "lucide-react";
import { LANGS, useI18n } from "@/lib/i18n";
import { cn } from "@/lib/utils";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function LanguageSwitcher({ className }: { className?: string }) {
  const { lang, setLang } = useI18n();
  const current = LANGS.find((l) => l.code === lang);
  const short = current?.short ?? "RU";

  return (
    <DropdownMenu>
      <DropdownMenuTrigger
        aria-label="Language"
        className={cn(
          "flex items-center gap-1.5 p-2 text-[0.65rem] tracking-[0.2em] text-ivory/80 uppercase transition-colors hover:text-gold focus:outline-none",
          className,
        )}
      >
        <Globe className="h-[1.05rem] w-[1.05rem]" />
        <span>{short}</span>
      </DropdownMenuTrigger>
      <DropdownMenuContent
        align="end"
        className="min-w-36 border-border/60 bg-card"
      >
        {LANGS.map((l) => (
          <DropdownMenuItem
            key={l.code}
            onSelect={() => setLang(l.code)}
            className={cn(
              "cursor-pointer text-xs tracking-[0.12em] uppercase",
              l.code === lang ? "text-gold" : "text-ivory/80",
            )}
          >
            {l.label}
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
