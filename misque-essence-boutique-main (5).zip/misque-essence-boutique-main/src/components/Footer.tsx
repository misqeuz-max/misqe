import { Link } from "@tanstack/react-router";
import { Instagram, Send } from "lucide-react";
import { Logo } from "@/components/Logo";
import { SITE, telegramUrl } from "@/config/site";
import { useT } from "@/lib/i18n";

export function Footer() {
  const t = useT();
  return (
    <footer className="border-t border-border/60 bg-onyx">
      <div className="mx-auto max-w-7xl px-6 py-16 lg:px-10">
        <div className="grid gap-12 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
          <div>
            <Logo size="md" className="items-start" />
            <p className="mt-6 max-w-xs text-sm leading-relaxed text-muted-foreground">
              {t("footer.tagline")}
            </p>
            <div className="mt-6 flex gap-3">
              <a
                href={SITE.instagramUrl}
                target="_blank"
                rel="noreferrer"
                aria-label={t("footer.instagram", "Instagram")}
                className="flex h-10 w-10 items-center justify-center border border-border/60 text-ivory/70 transition-colors hover:border-gold hover:text-gold"
              >
                <Instagram className="h-4 w-4" />
              </a>
              <a
                href={telegramUrl()}
                target="_blank"
                rel="noreferrer"
                aria-label={t("footer.telegram", "Telegram")}
                className="flex h-10 w-10 items-center justify-center border border-border/60 text-ivory/70 transition-colors hover:border-gold hover:text-gold"
              >
                <Send className="h-4 w-4" />
              </a>
            </div>
          </div>

          <FooterCol title={t("footer.shop", "Shop")}>
            <FooterLink to="/shop">{t("footer.allFragrances", "All Fragrances")}</FooterLink>
            <FooterLink to="/shop" search={{ category: "men" }}>
              {t("footer.men", "Men")}
            </FooterLink>
            <FooterLink to="/shop" search={{ category: "women" }}>
              {t("footer.women", "Women")}
            </FooterLink>
            <FooterLink to="/shop" search={{ category: "unisex" }}>
              {t("footer.unisex", "Unisex")}
            </FooterLink>
            <FooterLink to="/shop" search={{ category: "best" }}>
              {t("footer.bestSellers", "Best Sellers")}
            </FooterLink>
          </FooterCol>

          <FooterCol title={t("footer.maison", "Maison")}>
            <FooterLink to="/about">{t("footer.about", "About")}</FooterLink>
            <FooterLink to="/contact">{t("footer.contact", "Contact")}</FooterLink>
            <FooterLink to="/delivery">{t("footer.delivery", "Delivery")}</FooterLink>
          </FooterCol>

          <FooterCol title={t("footer.legal", "Legal")}>
            <FooterLink to="/privacy">{t("footer.privacy", "Privacy Policy")}</FooterLink>
            <FooterLink to="/terms">{t("footer.terms", "Terms")}</FooterLink>
          </FooterCol>
        </div>

        <div className="mt-14 hairline" />
        <p className="mt-8 text-center text-[0.65rem] tracking-luxe text-muted-foreground uppercase">
          {SITE.brand} — {t("footer.estd", "ESTD")} {SITE.established}
        </p>
      </div>
    </footer>
  );
}

function FooterCol({
  title,
  children,
}: {
  title: string;
  children: React.ReactNode;
}) {
  return (
    <div>
      <h3 className="mb-5 text-[0.65rem] tracking-luxe text-gold uppercase">
        {title}
      </h3>
      <ul className="space-y-3">{children}</ul>
    </div>
  );
}

function FooterLink({
  to,
  search,
  children,
}: {
  to: string;
  search?: Record<string, string>;
  children: React.ReactNode;
}) {
  return (
    <li>
      <Link
        to={to as never}
        search={search as never}
        className="text-sm text-muted-foreground transition-colors hover:text-gold"
      >
        {children}
      </Link>
    </li>
  );
}
