/**
 * Central brand + contact configuration.
 * Change these values to update the whole site.
 */
export const SITE = {
  brand: "MISQÉ PARFUM",
  established: 2026,
  tagline: "Your Signature. Your Scent.",
  /** Replace with your real Telegram username (no @ needed, both work). */
  telegramUsername: "@misqe_uz_admin",
  instagramUrl: "https://instagram.com/YOUR_INSTAGRAM",
  email: "orders@misqeparfum.com",
  phone: "+1 (000) 000-0000",
  currency: "som",
  deliveryFee: 5,
  freeDeliveryOver: 300000,
} as const;

export const telegramUrl = (text?: string) => {
  const user = SITE.telegramUsername.replace(/^@/, "");
  const base = `https://t.me/${user}`;
  return text ? `${base}?text=${encodeURIComponent(text)}` : base;
};

export const money = (value: number) =>
  `${value.toLocaleString().replace(/,/g, ".")}${SITE.currency}`;
